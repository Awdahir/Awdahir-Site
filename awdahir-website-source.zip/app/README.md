# Awdahir.com — Website Source Code

Personal finance publication built with React + TypeScript + Vite + Tailwind CSS.

## What's inside

- `src/pages/` — Home, About, Blog, Post, Insights, InsightPost, Resources, Store, Contact
- `src/data/content.ts` — all 22 blog essays, ebooks, resources, social links
- `src/data/insights.ts` — Market Insights notes
- `src/assets/` — portrait, avatar, book cover images
- `dist/` — the already-built site (static HTML/CSS/JS), ready to host anywhere

## Run it locally

Requires Node.js 18+.

```bash
npm install     # first time only
npm run dev     # live preview at http://localhost:5173
npm run build   # rebuilds dist/
```

## Deploy it (free options)

**Lovable / GitHub:**
1. Create a free GitHub account, make a new public repository
2. Upload this project's files (skip the `dist` folder if you like — Lovable rebuilds it)
3. In Lovable: Import from GitHub → select the repo → attach your custom domain in settings

**Netlify (simplest):**
1. Go to app.netlify.com/drop
2. Drag the `dist/` folder onto the page — your site is live instantly
3. Site settings → Domain management → add your custom domain

**Vercel:**
1. vercel.com → Add New Project → import the repo (or drag the folder)

## Notes

- Frontend-only site — no database, no server needed. Everything runs in the browser.
- Buy buttons link out to Payhip; contact form opens the visitor's email client.
- To add an essay: append to `POSTS` in `src/data/content.ts` (or ask Kimi to do it).
