import { useCallback, useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Home } from "@/pages/Home";
import { About } from "@/pages/About";
import { Blog } from "@/pages/Blog";
import { Post } from "@/pages/Post";
import { Resources } from "@/pages/Resources";
import { Store } from "@/pages/Store";
import { Contact } from "@/pages/Contact";
import { Insights } from "@/pages/Insights";
import { InsightPost } from "@/pages/InsightPost";
import { POSTS } from "@/data/content";
import { INSIGHTS } from "@/data/insights";
import type { Page } from "@/types/navigation";

function App() {
  const [page, setPage] = useState<Page>("home");
  const [postSlug, setPostSlug] = useState<string>(POSTS[0].slug);
  const [insightSlug, setInsightSlug] = useState<string>(INSIGHTS[0].slug);

  const navigate = useCallback((next: Page, slug?: string) => {
    if (next === "post" && slug) setPostSlug(slug);
    if (next === "insight-post" && slug) setInsightSlug(slug);
    setPage(next);
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, []);

  const headerPage: Page =
    page === "post"
      ? "blog"
      : page === "insight-post"
        ? "insights"
        : page;

  return (
    <div className="min-h-screen bg-paper text-ink">
      <Header page={headerPage} onNavigate={navigate} />
      <main>
        {page === "home" && <Home onNavigate={navigate} />}
        {page === "about" && <About onNavigate={navigate} />}
        {page === "blog" && <Blog onNavigate={navigate} />}
        {page === "post" && <Post slug={postSlug} onNavigate={navigate} />}
        {page === "insights" && <Insights onNavigate={navigate} />}
        {page === "insight-post" && (
          <InsightPost slug={insightSlug} onNavigate={navigate} />
        )}
        {page === "resources" && <Resources />}
        {page === "store" && <Store />}
        {page === "contact" && <Contact />}
      </main>
      <Footer onNavigate={navigate} />
    </div>
  );
}

export default App;
