export interface Post {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readTime: string;
  art: "chart" | "bars" | "coin" | "steps" | "wave" | "shield" | "grid";
  body: { heading?: string; paragraphs: string[] }[];
}

export interface Ebook {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  price: string;
  pages: string;
  format: string;
  motif: "circle" | "arcs" | "grid" | "stack";
  accent: "chart" | "mint" | "brick";
  payhipUrl: string;
  badge?: string;
}

export const SOCIALS = {
  substack: "https://awdahir.substack.com",
  twitter: "https://x.com/awdahir",
  patreon: "https://patreon.com/awdahir",
  payhip: "https://payhip.com/awdahir",
  email: "hello@awdahir.com",
};

export const POSTS: Post[] = [
  {
    slug: "generational-wealth-new-country",
    title: "Generational Wealth in a New Country: Starting From Zero Is Still Starting",
    excerpt:
      "Real estate, education funds for the kids, estate planning, and helping family back home — how immigrant families build wealth that outlives them, without the head start other families quietly inherited.",
    category: "Newcomers",
    date: "Sep 20, 2026",
    readTime: "20 min",
    art: "shield",
    body: [
      {
        paragraphs: [
          "There is a phrase you will hear in North America — 'generational wealth' — and if you are an immigrant, it can sting a little. Because generational wealth is exactly what most of us did not receive. Nobody handed us a paid-off house, a college fund started when we were born, or a grandfather's brokerage account. Many of us are the first generation in our families to even have a retirement account. We are not continuing a relay race; we are the first runner.",
          "But here is the reframe I want you to carry through this whole essay: starting from zero is still starting. Every wealthy family in this country has a first generation — someone who arrived, or was born, with nothing and built the base everyone else stands on. That person can be you. And because you are building deliberately, with open eyes, you can skip mistakes that took other families three generations to learn. Let me walk you through the four pillars: housing, the children's education, protecting it all with estate planning, and the question nobody else writes about — helping family back home without destroying what you are building.",
        ],
      },
      {
        heading: "Pillar one: housing, honestly",
        paragraphs: [
          "In most immigrant families, real estate is the dream. It is the asset you can see and touch, the asset that survived back home, the asset that says 'we belong here now.' I understand that pull deeply. But I want you to hold two truths at once. First truth: for most ordinary families, a home is the largest and most successful forced-savings plan they will ever have — every mortgage payment converts income into equity, and over decades that equity becomes the family's foundation. Second truth: a home is not automatically a good investment at any price, and buying too much house too early is one of the most common ways newcomer families become fragile.",
          "So the rules I teach: buy when you are staying — when your immigration status, job, and city are stable enough that five or more years in one place is likely. Buy beneath what the bank approves you for, because the bank's job is to maximize its loan, not your safety; a housing cost that leaves nothing for investing and emergencies is a golden cage. And remember that your halal index funds are also building wealth while you save for the down payment — renting for a few years while you invest is not failure, it is sequencing. The home is a pillar, not the whole building. Families who put every dollar into the house and nothing into investments often end up house-rich and cash-poor, which is a stressful kind of wealth.",
        ],
      },
      {
        heading: "Pillar two: the children's education",
        paragraphs: [
          "Ask immigrant parents what all the sacrifice is for, and most will say the same word: the kids. Education is our inheritance plan. And both countries hand you a remarkable tool for it — which most newcomers never hear about until it's too late. In Canada it is the RESP: a registered education savings account where the government adds a grant — free money, a percentage match on your contributions up to an annual limit — and the growth is tax-sheltered until the child studies. In the US it is the 529 plan: contributions grow tax-free and come out tax-free when used for education. The exact limits and grant percentages change over time, so check the official government pages, but the principle is permanent: these accounts are among the only places the government literally adds money to yours.",
          "Two pieces of hard-won advice here. First, start small but start — even a modest monthly amount opened when the child is young has eighteen years to compound, and in Canada the grant money alone makes it one of the best returns available anywhere. Second, and I say this with love: do not fund your child's education by emptying your own retirement. Your child can borrow for tuition if they must; nobody can borrow for retirement. A parent who is financially secure at seventy is a greater gift to their children than a fully funded degree followed by a parent who must be supported. Put your own oxygen mask on first — that is not selfishness, it is strategy.",
        ],
      },
      {
        heading: "Pillar three: the paperwork of love",
        paragraphs: [
          "Nobody likes this part, so I will be brief and blunt. If you died tomorrow, who gets what you have built? Without a will, the answer is: the government's default formula, decided slowly and expensively through courts, possibly split in ways you would never have chosen — and in the worst case, your children waiting in legal limbo while accounts freeze. Estate planning sounds like something for the rich. It is actually most urgent for families with the least margin for error, and for immigrants it carries an extra trap: assets and family members spread across two countries, under two legal systems that do not coordinate.",
          "The checklist is short and boring and essential. A will, updated when your family or assets change. Beneficiary designations on every account — your retirement accounts and life insurance pass by the named beneficiary, not by the will, so an outdated form can override your intentions entirely. Life insurance if anyone depends on your income — term insurance is cheap and honest; the expensive investment-linked policies are usually the industry's favorite, not yours. Powers of attorney, so someone you trust can act if you are incapacitated. And a simple document listing your accounts, assets, and contacts, in both countries if that is your reality. One weekend of paperwork. Decades of protection. This is the most loving boring task you will ever do.",
        ],
      },
      {
        heading: "Pillar four: the family back home",
        paragraphs: [
          "Now the question that is invisible in mainstream finance advice and unavoidable in our lives: what do we owe the people we left? Remittances and family support are real, honorable, and — if unstructured — capable of quietly consuming the entire engine of your wealth-building. I have watched nurses and engineers in Toronto and Houston who earn more than their parents ever dreamed of, yet own nothing at fifty, because the outflow never had a boundary.",
          "The solution is not coldness; it is structure. Give family support a line in your budget — a fixed number, chosen in advance, treated as non-negotiable as rent. When the number is fixed, saying yes inside it is easy and saying no beyond it stops being a personal rejection and becomes a plan. Where possible, shift from funding consumption to funding capability: school fees, a small business, a repair that raises the family's own earning power. Teach the system you have learned here. And have the honest conversation, early, that the money is not unlimited — that you are building something meant to help the family for decades, not just this month. A structured giver helps for thirty years. An unstructured giver burns out or goes broke in ten. Choose the thirty.",
        ],
      },
      {
        heading: "The long view",
        paragraphs: [
          "Generational wealth is not a number. It is a stack: some assets, some education, some protection, some knowledge passed down. Your children will grow up watching a parent who reads statements, asks about fees, invests every month, and talks about money without fear. That modeling alone is an inheritance most families never get. The accounts compound; the habits compound faster.",
          "So do not let anyone make you feel behind. The family with the paid-off house and the grandfather's account started somewhere too — with a first runner. You are running the hardest leg, the uphill one, the one with no map. Every pillar you put in place — the home bought wisely, the education account opened early, the will signed, the remittances structured — is a step your children will never have to take from zero. That is what it means to be the ancestor. Start where you are. The generation after you will stand on it.",
        ],
      },
    ],
  },
  {
    slug: "side-hustle-to-main-hustle",
    title: "The Side Hustle to Main Hustle Path: Turning Immigrant Grit Into Ownership",
    excerpt:
      "You already work harder than most people around you. The question is whether that effort builds someone else's asset or your own. How to start small, transfer your skills, navigate regulated professions, and grow a side income into a life you own.",
    category: "Newcomers",
    date: "Sep 8, 2026",
    readTime: "19 min",
    art: "steps",
    body: [
      {
        paragraphs: [
          "There is a joke in immigrant circles that is not really a joke: we don't have a work ethic, we have a work terror — the deep, inherited knowledge that nobody is coming to save us. That drive built our families' survival back home, and it powers us here through double shifts, night classes, and weekend jobs. But here is the question almost nobody asks us: is all that effort building your asset, or only someone else's? A salary is rented security — it stops the day you stop. An asset pays while you sleep. The side hustle, done right, is the bridge between the two.",
          "I want to be careful with this topic, because the internet has poisoned it. 'Side hustle' now conjures dropshipping gurus and rented Lamborghinis. That is not what this essay is about. What I want to walk you through is the slower, older, proven path: using skills you already have, evenings and weekends you can spare, and the specific advantages immigrants carry — to build a second income that can, over years, quietly become a first one. It isn't glamorous, but it works, and I'd rather give you something that works.",
        ],
      },
      {
        heading: "Your hidden advantages",
        paragraphs: [
          "Before the how, the why-you. Newcomers underestimate three assets they walk in with. The first is languages: every language you speak is a market — translation, tutoring, community services, businesses desperate to serve customers in their mother tongue. The second is network across borders: you understand two countries' products, prices, and needs, which is the entire foundation of trade; many successful immigrant businesses are simply bridges between here and there. The third is grit itself: the willingness to do unglamorous work well and show up every week is rarer than talent, and clients pay for it.",
          "There is also a fourth advantage nobody mentions: you know how to live below your means. A side business in its early years survives or dies on whether the household can tolerate lean months. Families who need every dollar of lifestyle cannot experiment; you can. The same skill that protects your budget protects your business.",
        ],
      },
      {
        heading: "Start with skills, not schemes",
        paragraphs: [
          "The strongest first side hustles sell what you already know. The accountant from Lagos does books for small businesses in Toronto. The nurse from Manila tutors nursing students online. The engineer from Lahore does CAD drafting on contract. The cook from Guadalajara caters weekend events. Notice the pattern: no inventory, no large upfront cost, no course to buy — just an existing skill, sold into a market that pays better here than it did there. This is the barbell logic applied to career: your job is the safe end, and the side hustle is the small, capped-cost bet with open upside.",
          "Getting the first client is the part that feels impossible, and it is simpler than it looks. Tell your community explicitly what you do — most first clients come through people who already trust you. Put your service where buyers look: freelance platforms for digital skills, local groups and community boards for local services. Do the first few jobs at a fair-but-modest price, overdeliver, and collect reviews like gold. Ten good reviews are worth more than any advertisement. Then raise your prices. Almost everyone waits too long to raise prices; the market will tell you, and a few 'no's are information, not insult.",
        ],
      },
      {
        heading: "The regulated profession problem",
        paragraphs: [
          "Now the hard truth many of you already know: if you were a doctor, engineer, nurse, teacher, or accountant back home, your credential may not transfer cleanly. This is one of the deepest frustrations of immigrant life — the surgeon driving for a ride-share app — and I will not insult you by pretending it is simple. But there is a strategic way through it, and it matters too much to skip.",
          "First, learn the licensing pathway early — every regulated profession in the US and Canada has a published process: credential evaluation, exams, supervised practice, sometimes bridging programs at colleges designed exactly for internationally trained professionals. Start it now, even if slowly, because the clock passes anyway; in three years you can either be three years into the process or three years older with nothing started. Second, while the process runs, work adjacent to your field: the internationally trained nurse works as a health aide or instructor; the engineer as a technician or project coordinator. Adjacent work keeps your skills warm, builds local references, and pays better than generic survival jobs. Third, count the cost honestly — exams, evaluations, and courses add up — and budget for them as what they are: an investment with one of the highest lifetime returns available to you. Your credential, once converted, is an asset that pays for forty years.",
        ],
      },
      {
        heading: "From side to main — and the rules that protect you",
        paragraphs: [
          "How does a side hustle become the main one? Slowly, and on evidence. The rule I teach: let the side income prove itself for a year — real revenue, real repeat clients, not one lucky month — and consider the leap only when it consistently replaces a meaningful share of your salary, or when it is clearly capped by your available hours. Keep the job while the bridge is being built. The person who quits on hope is gambling; the person who quits on a year of receipts is making a business decision.",
          "And some guardrails, learned from watching families do this well and badly. Keep the money separate from day one — a separate account for the side income, so you always know the truth about whether it works. Remember taxes: side income is taxable, and in both countries you should set aside a portion of every payment so April holds no surprises. Check your employment contract for conflicts before you start. Protect the downside: no big loans, no leased equipment, no inventory you cannot afford to lose — the hustle should be able to fail without touching your family's foundation. And pace yourself: the hustle that costs you your health or your family is not building a better life, it is just a second cage.",
        ],
      },
      {
        heading: "What this is really about",
        paragraphs: [
          "I will tell you why I care about this topic enough to make it a pillar of this site. Ownership changes how a person walks through the world. The immigrant with only a salary is one layoff from crisis; the immigrant with a salary, investments, and a small growing business is antifragile — each shock pushes work toward the doors that remain open. That is the real product of the side hustle. Not the extra money this month, though that helps. The product is the day you realize you are no longer trapped — that your effort is compounding into something with your name on it.",
          "Start absurdly small. Sell the skill once. Then twice. Raise the price. Tell your community. Keep the receipts — literally and figuratively. Our grandparents crossed oceans with less proof of concept than that. The grit is already in you. This is just pointing it at something you own.",
        ],
      },
    ],
  },
  {
    slug: "survival-budget",
    title: "The Survival Budget: Living Well in an Expensive City on an Entry-Level Wage",
    excerpt:
      "How to run a household in Toronto, New York, or Vancouver on a newcomer's income — the big three expenses, the remittance line that doesn't destroy your future, and the weekly habit that keeps it all together.",
    category: "Budgeting",
    date: "Aug 27, 2026",
    readTime: "18 min",
    art: "bars",
    body: [
      {
        paragraphs: [
          "Let me start with a number that shocks every newcomer: the rent. You arrive in Toronto or New York or Vancouver, you convert your savings from back home, and within weeks you understand that the rules here are different — a one-bedroom apartment can consume half an entry-level paycheck, and groceries for a family can match what fed you for a month back home. The math feels insulting. I have stood in that grocery aisle doing the conversion in my head. Everyone I know has.",
          "This essay is the practical guide I wish existed for that moment: how to actually run a household budget when the city is expensive and the wage is entry-level. Not theory — the big decisions that matter, the small ones that don't, and how to keep sending money to family back home without quietly bankrupting your own future. Because here is the truth that took me years to learn: in an expensive city, you do not budget your way to wealth by skipping coffees. You win or lose on three big decisions, and everything else is detail.",
        ],
      },
      {
        heading: "The big three",
        paragraphs: [
          "Housing, transportation, and food. In most household budgets these three eat seventy percent or more of everything — which means getting them right matters more than every other decision combined. Housing first: the standard advice is to keep it near a third of take-home pay, and in a high-cost city on a newcomer's wage, that often means choices the brochures don't advertise — a farther neighborhood on a transit line, a basement apartment, roommates or multi-generational living in the early years. Here is what I want you to hear without shame: those choices are not failure. They are the exact strategy wealthy immigrant families used before you. The family that shares a house for three years and invests the difference is not behind the family that rents alone in a nice postal code. In ten years the order reverses.",
          "Transportation second: a car in North America is the silent budget-killer — payment, insurance, fuel, parking, repairs easily reach a thousand dollars a month, and newcomers are often steered into the worst financing. If your city allows it, transit plus occasional rideshares is hundreds of dollars a month cheaper; if you truly need a car, buy reliable and modest with cash you have or financing you actually understand. Food third: cooking is the superpower our families already have. A household that cooks from scratch eats better than its neighbors for a fraction of the cost — this is one arena where the skills from home are literally worth thousands of dollars a year.",
        ],
      },
      {
        heading: "The remittance line",
        paragraphs: [
          "Now the part no mainstream budgeting guide will ever mention, and the reason I write for you specifically: family back home. The calls come, the needs are real, and the love is real. But unstructured giving is how newcomers earning good money end up with nothing at fifty. I have watched nurses and engineers who send everything home and keep nothing — admired as generous, and quietly one layoff from collapse. Generosity without structure is not kindness; it is a slow emergency for two households.",
          "The fix is the remittance line: a fixed number in your budget, decided calmly in advance, treated like rent. Inside the number, give freely and joyfully. Beyond it, the answer is no — not because you don't love them, but because the number exists. Have the honest conversation once, early: 'This is what I can send every month, reliably, for years.' Reliability is worth more to a family than occasional large rescues. And where you can, shift the giving from consumption to capability — school fees, tools, a small business — so the money builds their independence too. You are not an ATM. You are the family's long-term plan, and plans require structure.",
        ],
      },
      {
        heading: "The system that holds it together",
        paragraphs: [
          "You do not need an app with forty categories. You need three numbers and one habit. Number one: what actually lands in your account each month. Number two: your fixed obligations — rent, utilities, minimum debt payments, insurance, and yes, the remittance line. Number three: what's left — the decision pool for food, transport, life, and saving. Split the decision pool deliberately: living costs first, then an automatic transfer to savings on payday — even one or two hundred dollars — and then guilt-free spending with what remains.",
          "The habit is the weekly twenty minutes. Sunday evening, banking app open, two questions: did this week roughly match the plan, and does next week need adjusting? That is all. Monthly, check one number — your savings rate, the percentage you kept — because in the early years that number predicts your future better than your salary does. And build the buffer on purpose: the budget with zero slack is the budget abandoned by March. You are a person, not a spreadsheet, and the plan that respects that is the plan still running next year.",
        ],
      },
      {
        heading: "What this season is for",
        paragraphs: [
          "I want to end with something the budget spreadsheet cannot show. The survival years feel endless when you are inside them — the bus rides, the overtime, the careful arithmetic at the checkout. But looked at honestly, this season is doing something enormous: it is buying your foundation at the cheapest price it will ever be. Every month you keep your costs low while your income grows, the gap widens, and the gap is the engine of everything that comes later — the emergency fund, the first investments, the down payment, the breathing room.",
          "The families who struggle are rarely the ones who earned too little. They are the ones who let the expensive city set their spending. You already know how to live well on less — most of us learned it before we ever saw a dollar. Here, that skill is not poverty. It is a competitive advantage. Use it, hold the line on the big three, protect the remittance boundary, and give the season time to work. The city is expensive. Your discipline is worth more.",
        ],
      },
    ],
  },
  {
    slug: "financial-infrastructure-crash-course",
    title: "The Financial Infrastructure Crash Course Nobody Gave You",
    excerpt:
      "SIN and SSN, credit scores, banking, taxes, and government benefits — the invisible systems that run your financial life in Canada and the US, explained in plain language for people who were never handed the manual.",
    category: "Newcomers",
    date: "Aug 15, 2026",
    readTime: "21 min",
    art: "grid",
    body: [
      {
        paragraphs: [
          "When you arrive in Canada or the United States, you receive no manual. Nobody sits you down and explains that a nine-digit number will follow you for life, that an invisible score will decide your rent and your car loan, that the tax system expects you to report yourself every April, or that the government owes you money you may never claim. People who grew up here absorbed all of this by osmosis — from parents, teachers, and first jobs. You are expected to just know it. This essay is the orientation that should exist: the five systems, in plain language, with the newcomer traps marked.",
          "One note before we start: specific dollar limits and program rules change over time and differ by province and state, so treat this as the map, not the last detail — official government websites are always the final word. What does not change is how the systems think. Learn the thinking, and the details are easy to look up for the rest of your life.",
        ],
      },
      {
        heading: "Your identity number: SIN and SSN",
        paragraphs: [
          "In Canada it is the Social Insurance Number; in the US, the Social Security Number. Nine digits that become your financial fingerprint — employers need it to pay you, banks ask for it, the tax agency tracks you by it, and in the US your entire credit history hangs from it. Get yours in your first days: in Canada through Service Canada, in the US through the Social Security Administration, free, with your immigration documents.",
          "Now the warning, and it matters: these numbers are gold to identity thieves. With your number and basic details, a criminal can open credit in your name and leave you with the damage. Guard it like your passport. Memorize it, don't carry the card. Legitimate callers almost never ask for the whole number — and no government agency will ever call demanding it, or payment, by phone; that call is always a scam. If you suspect exposure, both countries let you place fraud alerts or freezes with the credit bureaus, free. Protect the number, and you protect everything built on it.",
        ],
      },
      {
        heading: "The credit score: your financial reputation",
        paragraphs: [
          "This is the system that surprises newcomers most. In North America, your financial trustworthiness is reduced to a number — roughly 300 to 850 in the US, 300 to 900 in Canada — calculated by private bureaus (Equifax, Experian, TransUnion) from your borrowing behavior. Landlords check it before renting to you. Lenders set your interest rate by it. Some employers and insurers peek at versions of it. And here is the trap: you arrive with no score at all — not a bad score, a blank one — which to the system looks almost as risky. Twenty years of perfect financial behavior back home does not transfer. You start invisible.",
          "The good news: a score is buildable, and faster than people think, because the recipe is public and boring. Get a credit product designed for beginners — a secured credit card, where your own deposit backs the limit, or a newcomer card from a major bank. Use it lightly — small purchases, well under the limit — and pay the full balance every month, on time, without exception. Payment history and how much of your limit you use drive most of the score. Keep old accounts open, since history length helps. Avoid a pile of applications at once, since each one leaves a mark. Do only this, and in a year or two you will have a score that opens doors — apartments, car loans at civilized rates, eventually a mortgage. You are not chasing a high score for vanity; you are building the reputation that makes everything else cheaper.",
        ],
      },
      {
        heading: "Banking: boring on purpose",
        paragraphs: [
          "Two accounts form the base: a checking account for money moving in and out, and a savings account for your emergency fund and short-term goals — ideally one that grows your money without riba, such as an Islamic bank's profit-sharing savings account or a halal high-yield option. Both countries offer newcomer packages at the major banks with fee waivers for the first year or more; ask for them explicitly, because nobody volunteers them. Compare monthly fees and minimum balance requirements, and remember you are not married to a bank — switching is normal here.",
          "A few things worth knowing early. Deposit insurance protects you: bank deposits are government-backed up to set limits — through the FDIC in the US and CDIC in Canada — which means an insured bank failing does not take your savings with it; check that your institution is covered. Overdraft fees are a tax on the stretched — decline overdraft coverage or keep a buffer so an unlucky Tuesday doesn't cost thirty-five dollars. And e-transfers and direct deposit are the plumbing of daily life; set up payroll direct deposit in your first week of any job, because payday automation is where every good money system begins.",
        ],
      },
      {
        heading: "Taxes: the system you report yourself to",
        paragraphs: [
          "Here is a cultural shock for many of us: in the US and Canada, the government does not simply send you a bill. You file a tax return every spring — reporting your own income, claiming your own deductions — and the system runs on honesty backed by audits. Employers withhold tax from each paycheck, and the annual return settles the difference: most employees with simple situations actually get refunds, because too much was withheld.",
          "File every year, even if your income was low or zero — because filing is what makes you eligible for the benefits in the next section, and because a clean filing history matters for your financial record. Help exists and much of it is free: community tax clinics serve newcomers and modest incomes in both countries, and simple situations can be filed with free or low-cost software. Keep your documents — slips, receipts, records of what you send home are not needed, but income and deductible expenses are. And mark this in your brain forever: no tax agency demands payment by gift card, crypto, or wire transfer, or threatens arrest by phone. Ever. That call is a scam, and it targets our communities precisely because the system is unfamiliar.",
        ],
      },
      {
        heading: "Benefits: the money you are owed",
        paragraphs: [
          "This is the section that pays you for reading. Both countries run benefit programs that put money into the accounts of eligible residents — and newcomers routinely leave thousands unclaimed because nobody told them. In Canada: the GST/HST credit, the Canada Child Benefit — a substantial monthly, tax-free payment per child for eligible families — provincial benefits, and the RESP grant where the government adds money to your child's education savings. In the US: the Earned Income Tax Credit and Child Tax Credit for working families, subsidized health coverage through the marketplace, and education savings through 529 plans.",
          "The mechanics matter: most benefits are triggered by filing your tax return — which is why filing every year is non-negotiable even with low income. Eligibility depends on your immigration status and residency, so verify your specific situation on the official government pages or with a community settlement agency — these agencies exist in every major city, staffed by people whose entire job is helping newcomers navigate exactly this, usually free. Use them without embarrassment. These programs are not charity; they are part of the social contract you pay into with every paycheck. Claiming what the law provides you is not taking advantage. It is participation.",
        ],
      },
      {
        heading: "The manual is short",
        paragraphs: [
          "Step back and the whole infrastructure compresses to a paragraph. Guard your identity number. Build your credit score with one boring card paid in full. Bank simply, with insured institutions and automated payday deposits. File your taxes every year, honestly, with free help if you need it. Claim every benefit you are owed. None of this requires wealth, connections, or perfect English — it requires knowing the systems exist, which is the one thing nobody bothered to tell us. Now you know. Teach the next family.",
        ],
      },
    ],
  },
  {
    slug: "immigrant-money-mindset",
    title: "The Immigrant Money Mindset: Scarcity, Guilt, and the Village Tax",
    excerpt:
      "Before the budgets and the accounts, there is the wiring: scarcity instincts earned in hard economies, guilt about wanting wealth, and the family obligations nobody in the West warns you about. Let's talk about all three, honestly.",
    category: "Newcomers",
    date: "Aug 3, 2026",
    readTime: "19 min",
    art: "wave",
    body: [
      {
        paragraphs: [
          "Every money guide starts in the same place: track your spending, open this account, buy that fund. This one starts earlier, in a place the guides never go — the wiring in your head. Because I have learned, from my own life and from hundreds of conversations with newcomers, that the biggest obstacles to building wealth in a new country are not financial. They are psychological. Three of them, to be exact: a scarcity instinct that once kept you safe, a guilt about wealth that your community may have taught you, and a set of family obligations that no Western budget template has a line for.",
          "None of these are flaws. All three were intelligent responses to real conditions. But instincts calibrated for one economy can quietly sabotage you in another — and the first step to updating them is seeing them clearly, without shame. That is what this essay is for. No judgment lives here. You survived things most financial writers cannot imagine. We are not fixing you; we are upgrading a system that was built for a different world.",
        ],
      },
      {
        heading: "Scarcity: the instinct that protected you",
        paragraphs: [
          "If you grew up where inflation ate savings, where banks failed, where tomorrow was genuinely uncertain, you learned rules that kept your family alive: spend money before it loses value, keep assets physical and close, trust people not institutions, grab opportunities immediately because they vanish, never let a good thing sit. These are not superstitions. They are rational lessons from a hard school.",
          "Now watch what those same rules do in a stable, low-inflation economy. 'Spend before it loses value' becomes an inability to hold savings — money burns until it is gone. 'Trust people, not institutions' becomes cash hidden from insured banks and fear of the stock market — which quietly guarantees the inflation loss you feared. 'Grab it now' becomes vulnerability to urgency — and urgency, I will tell you plainly, is the number one tool of every scammer who targets our communities. The instinct says act fast; the scammer's whole script is built to trigger exactly that.",
          "The update is not to delete the instinct — it is to aim it. Scarcity thinking's true core is respect for money, and that respect is gold here. What changes is the strategy it serves: in a stable system, holding productive assets is safer than holding cash; institutions with deposit insurance are safer than the mattress; and the opportunities worth taking are patient ones. Keep the discipline. Retire the fear.",
        ],
      },
      {
        heading: "The guilt around wealth",
        paragraphs: [
          "Now a quieter obstacle, one we rarely say aloud. In many of our cultures, visible wealth carries suspicion — the assumption that money must have come from somewhere dirty, the proverb about the rich man and the eye of the needle, the aunties who whisper. Some of us were raised to see wanting wealth as a character flaw. And so we sabotage: we undercharge, we turn down the raise conversation, we give away the surplus, we stay small — because being seen as wealthy feels socially dangerous in a way people who grew up here will never understand.",
          "Here is what I have come to believe, and I say it with love: money is a tool, and tools take the character of their user. Wealth in the hands of a person who sends remittances, funds cousins' educations, and carries their community is not greed — it is capacity multiplied. Every dollar you keep and grow is a dollar of future help you can give. The broke version of you can be generous with sympathy. The wealthy version of you can be generous with school fees, with seed money, with a safety net for the whole family. Wanting that is not a flaw. It is one of the most honorable ambitions a person from our background can hold. You are allowed to build. You are allowed to want to build.",
        ],
      },
      {
        heading: "The village tax",
        paragraphs: [
          "And now the one that makes Western finance advice useless to us if unaddressed: family obligation. The West has a phrase, 'black tax' or, as I call it, the village tax — the ongoing flow of money from the one who made it abroad back to parents, siblings, cousins, funerals, school fees, medical emergencies. Mainstream budgets pretend this line does not exist. Ours cannot. For many of us it is fifteen, twenty, thirty percent of income — a second rent, paid in love.",
          "The trap is not the giving. The trap is that the giving is unstructured — reactive, guilt-driven, unlimited. Every urgent call gets a yes, the amounts are random, and your own emergency fund never forms because the family's emergencies always come first. I have watched it hollow out good earners for decades. So here is the structure that saves both you and them: the village tax gets a line in your budget — a fixed monthly number, chosen calmly in advance, treated as seriously as rent. Inside the number, give with joy and zero guilt. Beyond it, the answer is a respectful no, or 'next month's line,' because the boundary is what makes the giving sustainable for thirty years instead of three.",
          "Two more upgrades. Where possible, convert gifts into capacity — fund the exam, the tools, the small business, not only the consumption — so the family's own engine grows and the calls slowly decrease. And have the honest conversation early: 'I can send this much, every month, reliably.' Predictable help is worth more to them than heroic rescues, and it protects the one asset the whole family depends on: your stability here.",
        ],
      },
      {
        heading: "From surviving to building",
        paragraphs: [
          "Put the three updates together and something shifts. Scarcity becomes discipline. Guilt becomes permission. The village tax becomes a budgeted act of love instead of an open wound in your finances. You stop running a survival strategy in a building season — because that is what moving to the West is: the season where the point is no longer to endure, but to construct.",
          "I write this site for the person who crossed a border with more courage than cash. The instincts that got you here are strong ones — they just need new instructions. That is the work of every essay here, and the heart of the book I am writing. Read the rest of the foundations — the infrastructure course, the survival budget, the investing path — and you will have both halves: the mindset and the machinery. You survived the hard part. Now build.",
        ],
      },
    ],
  },
  {
    slug: "employee-to-investor",
    title: "From Employee to Investor: The Accounts That Change Everything",
    excerpt:
      "TFSA and RRSP in Canada, 401(k) and Roth IRA in the US — what these accounts actually are, why immigrants fear the stock market, and the exact sequence to go from earning a paycheck to owning assets.",
    category: "Investing",
    date: "Jul 22, 2026",
    readTime: "20 min",
    art: "chart",
    body: [
      {
        paragraphs: [
          "Somewhere in your first months in a new country, a coworker mentions their 401(k) or their TFSA, and you nod like you understand. Inside, two feelings at once: embarrassment — everyone here seems to know something you don't — and suspicion — because where you come from, the stock market is where connected people profit and ordinary people get burned. This essay is for both feelings. By the end you will know exactly what these accounts are, why the fear is understandable but costly, and the precise order of steps that turns a paycheck into ownership.",
          "First, a distinction that, once it clicks, rearranges everything else: an account is not an investment. A TFSA, RRSP, 401(k), or IRA is a container — a legal wrapper with tax rules. What you put inside the container — cash, or index funds that own hundreds of real companies — is the investment. The most common mistake newcomers make is opening the account, leaving cash inside it, and believing they are 'investing.' Cash in the container is a parked car with the engine off. Let's fill the tank properly.",
        ],
      },
      {
        heading: "Why we fear the market — and what the fear costs",
        paragraphs: [
          "The immigrant's fear of the stock market is not ignorance; it is experience. Many of us watched banks collapse, currencies die, and connected insiders win while ordinary savers lost everything. In that world, avoiding the market was the smart move. But carry that instinct into a stable, regulated market and it quietly becomes the most expensive decision of your life. Here is the arithmetic: a broad stock market index in North America has historically returned, on average, around seven to ten percent a year over long periods — with crashes and recoveries along the way. Cash in a checking account returns almost nothing and loses purchasing power to inflation every year. Over thirty years, the difference between the two is not small. It is the difference between retiring and not.",
          "The fear also confuses two different things. Buying one company's stock because a friend tipped you — that really is close to gambling. Buying a low-cost index fund that owns hundreds of companies across the whole economy — that is ownership of the productive capacity of the country itself. Individual companies do fail; the whole market has always recovered, because it is made of businesses adapting, hiring, and earning. When you buy the index, you are not betting on a horse. You are buying the racetrack. I have written a whole essay on this — the Investing 101 piece built on Benjamin Graham and Ben Felix — and the conclusion stands: boring, diversified, automatic beats clever, concentrated, and scared.",
        ],
      },
      {
        heading: "The Canadian containers: TFSA and RRSP",
        paragraphs: [
          "Canada gives you two containers, and they work in opposite directions. The TFSA — Tax-Free Savings Account — takes money you have already paid tax on; everything it earns inside grows tax-free and comes out tax-free, forever. Contribution room accumulates every year from the year you turn eighteen and are a resident, and if you withdraw, the room comes back. For most lower and middle incomes, the TFSA is the best first container in the country — flexible, simple, and the government never touches the growth.",
          "The RRSP works the other way: you get a tax deduction now — contributing lowers this year's taxable income, often producing a refund — the money grows tax-sheltered, and you pay tax when you withdraw in retirement, ideally at a lower rate than you pay today. The RRSP shines when your income is high now and will be lower later; the TFSA shines when your income is modest now. Contribution limits for both change by year, so check the Canada Revenue Agency's official pages for your exact room — your CRA account shows it precisely. One warning that saves people pain: over-contributing is penalized, so verify your room before depositing, especially in your first years.",
        ],
      },
      {
        heading: "The American containers: 401(k) and IRA",
        paragraphs: [
          "In the US the system runs through your employer first. The 401(k) takes contributions straight from your paycheck — traditional contributions lower your taxable income now and are taxed at withdrawal; Roth contributions are taxed now and come out tax-free. And then there is the single best deal in American personal finance: the employer match. Many employers match your contributions up to a percentage of your salary. That match is an instant, guaranteed one-hundred-percent return on the matched money. No investment on earth reliably offers that. Not contributing enough to get the full match is turning down part of your salary — I say it that bluntly because it is that simple.",
          "If you have no 401(k) at work, or you have matched it fully and want more, the IRA is the individual version — you open it yourself at a brokerage, with the same traditional-or-Roth choice. Limits and rules adjust over time, so confirm current numbers with the IRS or your brokerage. One newcomer-specific note: contributions require earned income and there are residency and visa nuances for some account features — a single session with a tax professional in your first year pays for itself many times over.",
        ],
      },
      {
        heading: "The sequence — what to do, in order",
        paragraphs: [
          "Now the part I'd ask you to read twice. Step one: the starter emergency fund — even one month of expenses in a riba-free Islamic savings account — because investing without a cushion means the first car repair forces you to sell investments or reach for a credit card. Step two: the employer match, if you have one — contribute exactly enough to capture all of it; this is free money and nothing outranks it. Step three: kill high-interest debt, because a guaranteed twenty-plus-percent cost beats any expected market return. Step four: fill the tax-sheltered containers — TFSA or Roth-style space first for most modest incomes, traditional space when your income and tax rate are higher — with automatic monthly contributions into a low-cost, broadly diversified halal index fund — funds like SPUS or HLAL screen out companies whose business or debt levels conflict with Islamic principles, so your growth stays clean. Step five: automate and ignore — contributions run on payday, you review once a year, and you never sell because a headline scared you.",
          "Notice what is not on the list: stock tips, timing the market, waiting for the crash, watching the news. The investor's enemy was never the market. It is the person in the mirror reacting to the market. Your plan is written down in calm times precisely so the frightened version of you has instructions to follow.",
        ],
      },
      {
        heading: "The identity shift",
        paragraphs: [
          "I will close with the part that is not in any account agreement. Something changes inside a person the first year the statements show their money earning money — not much at first, a few hundred dollars, but earned while they slept, while they worked, while they lived. That is the moment an employee starts becoming an investor. And for an immigrant it carries extra weight: back home, systems extracted from our families; here, for the first time, a system is compounding for you. That is not a small thing. That is one of the reasons we crossed.",
          "Open the container this week. Put the index fund inside it. Automate the contribution. Then go live your life — the account will be working every hour of it.",
        ],
      },
    ],
  },
  {
    slug: "avoiding-predators",
    title: "Avoiding Predators: The Scams That Hunt Immigrant Communities",
    excerpt:
      "Payday loans, MLMs, credit repair schemes, forex mentors, fake immigration services — why predators target newcomers specifically, how each trap actually works, and the simple rules that make you unhuntable.",
    category: "Newcomers",
    date: "Jul 10, 2026",
    readTime: "19 min",
    art: "coin",
    body: [
      {
        paragraphs: [
          "I want to start with something uncomfortable, because this essay exists to protect you: in almost every immigrant community in North America, there is an economy of predators. Payday loan shops clustered in newcomer neighborhoods. Multi-level marketing recruiters working through churches, mosques, temples, and WhatsApp groups. 'Credit repair' specialists. Forex and crypto 'mentors' with rented Lamborghinis. Fake immigration consultants. It is not an accident that these schemes find us. It is a business model, and understanding why it works is the first step to making sure it never works on you.",
          "Predators target newcomers for four reasons, and naming them takes away their power. First, information asymmetry: you don't yet know what normal looks like — what a fair interest rate is, what a real financial advisor does, what the government will and will never ask of you. Second, urgency: newcomers need things fast — credit, income, papers — and urgency is the predator's favorite lever. Third, trust networks: we rightly trust people from our own community, our language, our faith — and scammers exploit exactly that trust, because a recommendation from 'one of us' bypasses the skepticism we'd apply to a stranger. Fourth, shame: victims often stay silent rather than admit they were fooled, which means the predator is never warned about and hunts on. So let me say it clearly: if you have ever fallen for one of these, you were not stupid. You were hunted by professionals. The only shame belongs to them.",
        ],
      },
      {
        heading: "The payday loan trap",
        paragraphs: [
          "The storefront looks friendly: fast cash, no credit check, money today. Here is how it actually works. You borrow a few hundred dollars until payday and pay a fee that sounds small — say fifteen dollars per hundred borrowed for two weeks. Small, right? Annualized, that fee is an interest rate of several hundred percent. Compare: a credit card — itself expensive debt — charges around twenty percent a year. The payday loan is ten to twenty times worse. And the design is deliberate: the loan is due in full in two weeks, which almost nobody in genuine need can do, so you roll it over, pay another fee, and roll it again. The industry's profit comes almost entirely from repeat borrowers trapped in the cycle.",
          "The escape routes: if you are employed, ask your employer about an advance — many will help quietly. Credit unions often offer small emergency loans at civilized rates. In Canada and the US, nonprofit credit counseling agencies exist and their first consultations are typically free. And the long-term fix is the emergency fund — even five hundred dollars of cushion breaks the payday lender's business model, because their entire customer is the person with zero slack. This is one more reason the emergency fund is the foundation of everything I teach.",
        ],
      },
      {
        heading: "The MLM mirage",
        paragraphs: [
          "You know the pitch, because it usually comes from someone you know: be your own boss, work from your phone, financial freedom, our sister from back home made ten thousand last month. Multi-level marketing companies sell products — supplements, cosmetics, oils — but the real product is the recruitment of sellers. The mathematics are brutal and public: the companies' own income disclosure statements show that the overwhelming majority of participants earn little or nothing, and many lose money on starter kits, inventory, and fees. The tiny percentage who earn real money sit at the top of a structure that requires everyone beneath them to fail.",
          "Why does it spread through our communities like fire? Because it is marketed through trust, in our languages, at our gatherings, to people who are hungry for opportunity and flexible work. The recruiter is often your cousin, your neighbor, your sister's friend — a good person who is themselves losing money and hoping to recover it through you. The questions that protect you: Do the earnings come mostly from selling products to real outside customers, or from recruiting? What does the company's own legally required income disclosure say the average participant earns? Can I leave without losing money I paid in? If the answers are recruitment, almost nothing, and no — walk away with love, and warn the next person. The painful duty in our communities is to be the one who breaks the chain.",
        ],
      },
      {
        heading: "Credit repair, forex mentors, and other fantasies",
        paragraphs: [
          "'Credit repair' companies promise to erase bad credit for a fee. The truth: nobody can legally remove accurate negative information from your credit report — not them, not anyone. What they do for hundreds of dollars, you can do free: dispute genuine errors yourself with the credit bureaus, pay down balances, and wait for time to heal the record. Anyone selling deletion of accurate history is selling fiction.",
          "Then there are the forex and crypto mentors — the young man on Instagram with the luxury car showing charts and promising to teach you to trade for a five-hundred-dollar course, or to trade for you. Understand the economics: foreign exchange and day trading are among the hardest games on earth, where the vast majority of retail participants lose money to professionals with faster machines and deeper pockets. Anyone who could reliably beat those markets would never need to sell courses to strangers. The car is rented; the screenshots are curated; the course is the business. This is also the place to say clearly: real investing — the boring, automatic, index-fund kind I teach here — is the opposite of all this. It requires no mentor, no signals group, no urgency. If an opportunity demands that you decide today, the answer is no. Legitimate money is patient.",
        ],
      },
      {
        heading: "Immigration fraud and official impersonators",
        paragraphs: [
          "The cruelest traps exploit the thing that matters most: your status. Fake consultants charge thousands for forms you could file yourself or for guarantees no one can give — nobody can guarantee a visa, and anyone who does is lying. Government impersonation scams call or text claiming to be from immigration, the tax agency, or the police, demanding immediate payment by gift cards, wire transfer, or crypto to avoid arrest or deportation. Know this as absolute law: no government agency in the US or Canada demands payment by gift card or cryptocurrency, ever, and no real officer threatens arrest by phone to extract money. Hang up. Call the agency back through its official published number. Report the attempt.",
          "For real immigration help, use licensed professionals — in the US, licensed attorneys or accredited representatives; in Canada, regulated immigration consultants or lawyers — and verify the license on the official regulator's public register before paying anyone. Keep your own copies of every document and every filing. Your papers are your foundation; never let them exist only in someone else's hands.",
        ],
      },
      {
        heading: "The five rules that make you unhuntable",
        paragraphs: [
          "After all the specific traps, the defenses compress into five rules that stop nearly everything. One: urgency is the tell — any offer that must be decided now is designed to bypass your judgment; sleep on everything. Two: verify independently — check licenses on official registers, look up the company's income disclosures and complaints, call agencies back on numbers you find yourself. Three: if you cannot explain how the money is made, the money is made from you. Four: trust, but verify — community trust is precious, which is exactly why predators wear it as a costume; a recommendation from one of us is the beginning of research, not the end. Five: talk about it — predators depend on silence and shame, so make scam stories normal dinner-table conversation in your family and community.",
          "I will end where I began. Our communities are targeted because we are ambitious, trusting, and in a hurry — three virtues aimed at the wrong door. The defense is not suspicion of everyone; it is a small set of habits applied every time. You have crossed borders and rebuilt a life from nothing. Compared to that, seeing through a man with a rented Lamborghini is easy. Guard what you are building. It is worth guarding.",
        ],
      },
    ],
  },
  {
    slug: "antifragile-stronger-from-storm",
    title: "Stronger From the Storm: What Antifragile Taught Me About Immigrant Life",
    excerpt:
      "Nassim Taleb's Antifragile is brilliant, infuriating, and impossible to forget. Its central idea — that some things don't just survive chaos but feed on it — might be the most honest description of the immigrant journey ever written.",
    category: "Books",
    date: "Jun 28, 2026",
    readTime: "22 min",
    art: "wave",
    body: [
      {
        paragraphs: [
          "I have been listening to the audiobook of Antifragile by Nassim Nicholas Taleb, and I need to be honest with you about something: this book gave me intellectual whiplash. One chapter would have me nodding along, thinking this is one of the most important ideas I have ever encountered. The next chapter would have me wincing at the author's arrogance, his grudges, his tendency to insult entire professions by name. I kept asking myself: is this man a genius, a crank, or somehow both?",
          "If you have read Taleb, you know exactly the feeling I am describing. And if you haven't — this essay is my attempt to give you the gold without the gravel. Because underneath the bombast, Antifragile contains an idea that I believe every newcomer to the West needs in their bones. It is the idea that explains why some families arrive with nothing and build unshakeable lives, while others arrive with advantages and crack under the first real stress. And it is an idea you already understand better than most professors — because you have lived it.",
        ],
      },
      {
        heading: "The wind that puts out the candle",
        paragraphs: [
          "Taleb opens the book with a line I have not stopped thinking about: wind extinguishes a candle and energizes fire. Same wind. Two completely different outcomes. The candle and the fire are not equally tough — they are different kinds of things. And that observation turns out to be the key to everything.",
          "From it, Taleb builds a simple triad — three categories that everything in the world falls into. The fragile breaks under stress and shocks: a wine glass, an over-leveraged bank, a life with zero savings and one income. The robust withstands stress but doesn't improve: a rock, a government bond, a steady paycheck. And then there is the third category — the one Taleb had to invent a word for, because no language on earth had it. The antifragile gets stronger from stress. It needs shocks, volatility, and disorder the way muscles need resistance. Remove the stress and it doesn't stay the same — it weakens.",
          "Think about your own body. Lift weights and you tear muscle fibers — small, controlled damage — and the body rebuilds them stronger than before. Avoid all physical stress and your muscles melt away. That is antifragility. Your immune system works the same way: a child raised in a sterile bubble has weak immunity, while exposure to ordinary dirt and germs builds the defenses that protect them for life. Evolution itself is antifragile — it runs on stress, error, and catastrophe, and each disaster leaves the survivors stronger.",
        ],
      },
      {
        heading: "The category nobody named",
        paragraphs: [
          "What struck me most is that we all knew this third category existed, but we never had a word for it. We say 'what doesn't kill you makes you stronger' — grandmothers have said it for centuries — but our formal thinking, our economics, our risk management, our education systems, only ever recognized two categories: things that break, and things that resist. Nobody modeled the things that improve from disorder.",
          "And once you see the third category, you see it everywhere. A restaurant industry gets better when bad restaurants fail — the failures are information, and the survivors absorb the lessons. An economy that never allows small recessions builds up hidden weaknesses until a giant one arrives. A person who has never been allowed to fail at anything small shatters the first time they fail at something big. Taleb's word for the people who don't understand this is 'fragilistas' — well-meaning experts, planners, and overprotective parents who try to remove every shock from a system, and in doing so guarantee that when the shock finally comes, it is catastrophic.",
        ],
      },
      {
        heading: "The most antifragile people on earth",
        paragraphs: [
          "Here is where I want to speak directly to my immigrant readers, because this is the part of the book I experienced most personally. Think about what it actually takes to leave your country and start again in America or Canada or anywhere in the West. You walked away from your language, your family network, your credentials that nobody here recognizes, your whole social operating system. You landed in a place where the rules were invisible to you — no orientation, no handbook — and you figured it out anyway. You worked jobs beneath your education while studying at night. You learned a new financial system with zero guidance. You absorbed shocks that would flatten people who grew up comfortable.",
          "By Taleb's framework, you are the fire, not the candle. Every shock made you more capable. And I want to say this without any shame attached, because too many newcomers carry quiet shame about their starting point — the accent, the gaps in local knowledge, the degree that got discounted. The antifragile frame turns that story on its head: the difficulty was not your defect. It was your training. The person who has only ever known stability is fragile in ways they cannot see. You have stress-tested yourself against reality and you are still standing. That is not a weakness in your story. That is the whole strength of it.",
          "But — and this is the crucial turn — antifragility is not automatic. The storm only strengthens you if the stress is survivable and you are positioned to gain from it. A shock that wipes you out doesn't make you stronger; it just wipes you out. Taleb is very clear on this: the point is never to seek ruin. The point is to structure your life so that the shocks you absorb are small enough to survive and frequent enough to teach. Small failures, small losses, small experiments — each one is a vaccine dose of reality.",
        ],
      },
      {
        heading: "Where fragility hides",
        paragraphs: [
          "Now apply the triad to money and work, and some uncomfortable things become visible. The job that feels safest — one employer, one salary, a mortgage sized to the maximum the bank allowed, credit payments depending on every paycheck arriving on time — is often the most fragile structure of all. It looks robust. But it has one load-bearing wall, and if that wall cracks, everything comes down at once.",
          "The newcomer version of this trap is familiar to many of us: you finally land the good job, and within two years the apartment is upgraded, the car is financed, and the entire household runs at full capacity with zero slack. I have written before about the arrival effect — the way a first Western paycheck feels enormous and quietly inflates your lifestyle until the 'enormous' salary is fully consumed. Through Taleb's lens, the arrival effect is fragility construction. You took a position of natural antifragility — your ability to live well on less, which you brought from home — and traded it for a structure that needs everything to go right.",
          "The opposite looks boring from the outside: savings that can absorb a layoff, skills that transfer between industries, expenses low enough that losing one income is a problem rather than a catastrophe, a small side project that could grow. Nothing about that life is dramatic. But stress hits it and it bends, learns, and comes back stronger. That is the whole game.",
        ],
      },
      {
        heading: "The uncomfortable part: let's talk about Taleb himself",
        paragraphs: [
          "I promised you honesty, so here it is. This book is deeply polarizing, and the polarization is not a misunderstanding. Taleb is a Distinguished Professor of Risk Engineering at NYU and a former options trader who made his fortune betting on market crashes — a man with genuine skin in the game. The public rates the book highly, around four stars across tens of thousands of reviews. But critics — including academics in medicine and the social sciences — push back hard. They call the book scattered, repetitive, and arrogant. A five-hundred-page book that could have been one hundred. A reviewer in psychiatry objected strongly to his dismissive takes on mental health care. Even his admirers admit you must tolerate a lot of dogmatic bombast to reach the insight.",
          "My own take, after sitting with it: read the book for the concepts, not for the man. The idea of antifragility is real and important — it belongs in the same conversation as evolution and complex systems. But you do not need to adopt Taleb's personality along with his philosophy. You can believe that systems need stress to grow without believing that all academics are frauds or that all modern medicine is a conspiracy. Take the framework. Leave the feuds.",
          "And actually, there is a meta-lesson in that, which Taleb himself would appreciate: information is antifragile. A strong idea survives being separated from a flawed messenger. The discomfort this book creates — the dissonance you feel when a sentence is both brilliant and infuriating — is not a bug in your reading. It is the book working on you. If nothing you read ever makes you uncomfortable, you are not learning anything new.",
        ],
      },
      {
        heading: "What I am taking from it",
        paragraphs: [
          "So here is my personal summary, the way I have written it in my own notes. First: ask of everything in your life — my job, my savings, my expenses, my plans — which of the three categories is this? Fragile, robust, or antifragile? Just naming the category changes your decisions. Second: never let a single shock be able to end you. Survival is the floor; everything else is built on top of it. Third: stop trying to eliminate all volatility from life. You cannot do it, and the attempt makes you fragile. Instead, take small doses of difficulty on purpose — new skills, small experiments, controlled risks — and let them train you.",
          "In the essays ahead, I will go deeper into how Taleb applies this to money — his famous barbell strategy — and I will give you a list of the twenty-five lessons from this book that changed how I think about work, investing, health, and raising children. Some of them will challenge you. Good. That is what they are for.",
          "The wind is going to blow. It always does. The only question is whether you have built yourself as a candle or as a fire.",
        ],
      },
      {
        heading: "Sources and further reading",
        paragraphs: [
          "Nassim Nicholas Taleb, Antifragile: Things That Gain from Disorder (2012) — Book I for the triad, Book VII for the ethics. Taleb's earlier Fooled by Randomness and The Black Swan set the stage. For the critical perspective, the long-form reviews of Antifragile across Goodreads and academic blogs capture the polarized reception honestly. Seneca's Letters from a Stoic — Taleb's chapters on Stoicism and 'premeditatio malorum' sent me back to the original, which is two thousand years old and reads like it was written last week.",
        ],
      },
    ],
  },
  {
    slug: "antifragile-barbell-strategy",
    title: "The Barbell: Taleb's Strange Rule for Money That Both Protects and Grows",
    excerpt:
      "Most financial advice lives in the mushy middle — medium risk, medium reward, hidden danger. Taleb's barbell strategy says the middle is where fragility hides. Here is how the barbell works, and how a newcomer can actually use it.",
    category: "Investing",
    date: "Jun 16, 2026",
    readTime: "21 min",
    art: "coin",
    body: [
      {
        paragraphs: [
          "Picture a barbell — the kind in a gym. Weight on one end, weight on the other end, and nothing in the middle but a bar. Now imagine your financial life built the same way: one end extremely safe, the other end open to big opportunity, and the middle — the place where almost all financial advice tells you to live — deliberately empty.",
          "That image is the heart of Nassim Taleb's investment philosophy in Antifragile, and it confused me at first. Surely the sensible place for money is the middle? Medium risk, medium reward, a 'balanced portfolio,' moderation in all things? That is what the brochures say. Taleb's answer is one of the most provocative claims in modern finance: the middle is where fragility hides. Let me explain why, and then — more importantly — how an ordinary person, an immigrant building a first financial life in the West, can use this idea without touching a single complex financial product.",
        ],
      },
      {
        heading: "Why the middle is dangerous",
        paragraphs: [
          "Taleb's complaint about medium-risk strategies is that their risk is invisible. A portfolio of 'moderate' investments feels safe day to day — it wiggles a little, nothing scary. But because you cannot see the risk, you cannot size it, and because you cannot size it, you take too much of it. Then the rare event arrives — the 2008 crash, the pandemic, the war, the sector collapse — and the 'medium risk' portfolio falls forty percent while its owner discovers that medium risk was a story, not a measurement.",
          "The barbell solves this with honesty. The safe end is truly safe — cash in an Islamic, riba-free savings account, sukuk funds (Islamic asset-backed certificates that pay profit from real assets instead of interest), the kind of assets that will be there no matter what headline arrives tomorrow. Because that end is genuinely protected, you know exactly how much you can lose: only what is on the risky end. And the risky end is sized so that if it goes to zero — truly zero — your life continues unchanged. The result is a strange and beautiful property: your downside is capped and known, while your upside is unlimited. Taleb calls this asymmetry, or convexity — you cannot be hurt badly, but you can be helped enormously.",
          "His own career was the extreme version. As a trader, he spent years making small, boring, steady losses buying far-out-of-the-money options — cheap insurance against market crashes that almost never paid. People mocked the strategy as bleeding money. Then the crashes came, and the payoffs were enormous. Small, survivable losses in exchange for rare, transformative gains. Maximum safety at one end, maximum possibility at the other, nothing in between.",
        ],
      },
      {
        heading: "What the barbell looks like for normal people",
        paragraphs: [
          "Now, you and I are not options traders, and I am not going to pretend otherwise. But the barbell is not really about options — it is a shape, and the shape fits an ordinary life remarkably well. Here is how I translate it for newcomers.",
          "The safe end of your barbell is your foundation: an emergency fund of three to six months of expenses in a riba-free savings account — Islamic banks offer profit-sharing accounts that pay you without a cent of interest — your core retirement investing in boring, broadly diversified, low-cost halal index funds like SPUS through automatic monthly contributions, and — this is the part Taleb insists on that most advice skips — no exposure that can wipe you out. No leverage. No borrowing to invest. No single stock that your family's future depends on. No crypto position sized so large that a bad year becomes a bad decade. This end of the barbell should be, frankly, dull. Its job is to make you unkillable.",
          "The risky end is small — think five to ten percent of your money, not half — and it is where you are allowed to dream. This might be a measured position in Bitcoin or other speculative assets. It might be a small business or a side project you fund yourself. It might be your own education — a certification, a skill, a license — which is the most underrated speculative asset a newcomer owns, because its upside follows you for forty years and nobody can take it away. The rule is simple: everything on this end must be able to go to zero without changing your life. If losing it would hurt, it does not belong on the risky end. It belongs on the safe end, or nowhere.",
          "And the middle? The middle is the lifestyle mortgage at the maximum the bank approved, the car loan that assumes every paycheck arrives forever, the 'sure thing' stock tip from a coworker, the leveraged real estate scheme pitched at a community event. The middle is where people take risks they cannot see for returns that do not compensate them. Leave it empty.",
        ],
      },
      {
        heading: "Optionality: the right, not the obligation",
        paragraphs: [
          "Underneath the barbell sits a deeper idea that Taleb considers the real engine of antifragility: optionality. An option, in life as in finance, is the right but not the obligation to do something. You want to collect options the way a sailor collects favorable winds — cheap to hold, powerful when conditions turn.",
          "This reframed how I think about dozens of ordinary decisions. An emergency fund is optionality: it is the option to quit a toxic job, to say no to a bad deal, to wait for a better opportunity instead of grabbing the first one out of desperation. Low fixed expenses are optionality: they let you survive a layoff at your own pace instead of the bank's pace. A skill is optionality: it is the right to pivot industries when yours declines. A side project is optionality: most will fail quietly, and one might become a business — capped downside, open upside. That is the barbell shape again, appearing in life rather than in a brokerage account.",
          "For immigrants, optionality has an extra dimension that I think about constantly. Credentials are options — the license or certification is the right to work in a field, whether or not you use it today. Language is an option. Legal status, citizenship, a second passport where possible — these are options on entire countries. Our grandparents understood this instinctively when they kept documents in order and skills portable. Taleb just gives us the vocabulary: collect options, avoid obligations that lock you in, and never pay so much for an option that buying it endangers you.",
        ],
      },
      {
        heading: "Via negativa: the wisdom of subtraction",
        paragraphs: [
          "There is a second Taleb idea woven through all of this, and it might be my favorite because it is so contrary to how finance is usually sold. He calls it via negativa — the negative way. The insight: we know what is wrong with far more confidence than we know what is right. You cannot reliably identify the investment that will make you rich, but you can identify with near-certainty the behaviors that will make you poor. So instead of adding — more strategies, more products, more complexity — you subtract.",
          "Via negativa for money looks like this: remove high-interest debt before you chase returns, because a guaranteed twenty-percent cost beats almost any uncertain gain. Remove fees, because a two-percent annual fee quietly consumes a third of your lifetime returns. Remove leverage, because it converts temporary setbacks into permanent wipeouts. Remove the financial products you cannot explain to a teenager — not because you are unintelligent, but because complexity is where hidden fragility lives. Remove the middle.",
          "Notice what is left after the subtraction: an emergency fund, low expenses, automatic contributions into simple diversified index funds, and a small budget for measured bets and personal growth. It is almost embarrassingly plain. That is the point. Taleb trusts what has survived — he calls it the Lindy effect, the idea that things which have lasted a long time are likely to keep lasting — and plain, boring financial structures have survived every crash in modern history while the clever, optimized, over-engineered ones have not.",
        ],
      },
      {
        heading: "What I am taking from it",
        paragraphs: [
          "I will be transparent about how this book has changed my own thinking. I used to ask, about money decisions, 'what is the return?' Now I ask three questions, in order. First: what is the worst case, and can I survive it completely? If the answer is no, the discussion is over — no return justifies ruin. Second: what is my downside if I am wrong, and is it capped and known? Third: is the upside open? Does this decision give me options, or does it lock me in?",
          "I have also become suspicious of the middle in a way I was not before. When an offer is presented as balanced, moderate, just-right — a structured product, a complex insurance-investment hybrid, a medium-risk fund with a medium fee — I now instinctively ask where the fragility is hiding, because Taleb taught me it is always hiding somewhere. The honest alternatives are almost always simpler: very safe, or openly speculative, and you choose the split with your eyes open.",
          "One warning, in the spirit of honesty I try to keep with you: do not use the barbell as a costume for gambling. The risky end works because it is small. Ten percent, not fifty. If you find yourself stretching the speculative side because you are excited, remember the rule that makes the whole structure antifragile — everything on that end must be able to go to zero without changing your life. The candle cannot energize itself. Only the fire can feed on the wind, and the fire is built patiently, on the safe end, one automatic contribution at a time.",
        ],
      },
      {
        heading: "Sources and further reading",
        paragraphs: [
          "Nassim Nicholas Taleb, Antifragile (2012) — Book IV on optionality and the chapters on the barbell are the core. For the safer end of the barbell done properly, Benjamin Graham's The Intelligent Investor and Ben Felix's Common Sense Investing channel — see my Investing 101 essay — cover index investing with the evidence. For tail-risk thinking from practitioners, the writings of Universa Investments and Taleb's technical companion, Dynamic Hedging, show where the professional version of these ideas lives. And for the Stoic root of downside-protection thinking, Seneca's Letters — the oldest and best source on the shelf.",
        ],
      },
    ],
  },
  {
    slug: "antifragile-25-lessons",
    title: "25 Lessons From Antifragile That Changed How I Think About Money and Life",
    excerpt:
      "From the barbell to the Lindy effect, from skin in the game to via negativa — the twenty-five ideas from Taleb's most controversial book that I keep returning to, each one translated into plain language and real life.",
    category: "Books",
    date: "Jun 4, 2026",
    readTime: "24 min",
    art: "grid",
    body: [
      {
        paragraphs: [
          "This is the list I wish someone had handed me when I started reading Antifragile. The book is five hundred pages of brilliance and bombast mixed together, and mining the gold takes patience — so I did the mining for you. What follows are the twenty-five lessons that stuck, the ones I actually use, each one explained simply and followed by an example from real life.",
          "A word before we start, in the spirit of honesty I keep with you on this site: these are the lessons as I understand and apply them, filtered through my own judgment. Taleb says plenty of things I don't adopt, and I have written elsewhere about taking the concepts while leaving the controversies. This list is the keeper shelf. It is also, I will admit, the intellectual backbone of the book I am writing for newcomers — these ideas appear throughout it, translated into a step-by-step system. Let's go.",
        ],
      },
      {
        heading: "The core philosophy",
        paragraphs: [
          "1. Sort everything into three categories. Fragile breaks under stress, robust withstands it, antifragile grows from it. A wine glass, a boulder, and a muscle are your three models. Before any big decision — a job, a loan, an investment — ask which category the result lands in. Just asking the question changes what you choose.",
          "2. Seek small doses of volatility on purpose. Systems that never face small stresses become vulnerable to the big one. This is why vaccines work — a weakened dose trains the immune system for the real thing. In life: take the stretch assignment, learn the intimidating skill, have the awkward conversation. Small, frequent stress is training, not danger.",
          "3. Don't touristify your life. Taleb's word 'touristification' means removing all randomness and spontaneity — over-scheduling, over-planning, over-protecting. The parent who schedules every minute of a child's day raises an adult who cannot handle a boring Tuesday or an unexpected problem. Leave slack in your calendar, your budget, and your plans. Slack is not waste; it is shock absorption.",
          "4. Respect what has survived — the Lindy effect. A book that has been read for two thousand years will probably be read for a hundred more; a bestseller from last year will probably be forgotten by next year. Gold has stored value for five thousand years; the newest financial product has survived nothing. When choosing what to learn, what to trust, and what to own, age is evidence.",
          "5. Keep your identity small. If you define yourself by a fixed position — a party, a tribe, a single profession — then every challenge to it feels like an attack on you, and you become intellectually fragile. Define yourself instead as someone who updates. You can change your mind without losing yourself. In a fast-changing economy, the flexible identity is not just happier — it is more employable.",
        ],
      },
      {
        heading: "Money and investing",
        paragraphs: [
          "6. Build your finances as a barbell. Put the great majority of your money in truly safe places — an emergency fund in a riba-free account, boring diversified halal index funds on automatic contributions — and a small slice, five or ten percent, in openly speculative bets with big upside. Skip the mushy middle entirely. The safe end makes you unkillable; the risky end gives you a lottery ticket you can actually afford.",
          "7. Prefer asymmetry everywhere. Look for setups where your downside is small and capped and your upside is large and open. A low-cost certification with a lifetime of earning power is asymmetry. A side project that costs weekends but could become a business is asymmetry. A leveraged investment that can wipe you out is the opposite — reverse asymmetry — and it is how families get destroyed.",
          "8. Never accept blow-up risk. No matter how good the returns look, never hold a position that can go to zero and take you with it. Even if it works ninety-nine times, the hundredth time ends the game — and Taleb's deepest rule is that you must never leave the game. Before investing in anything, ask: if this went to zero tomorrow, does my life change? If yes, you are too exposed.",
          "9. Treat debt as fragility. Debt removes your option to walk away — payments are due in good times and bad, which means a leveraged household must make desperate decisions exactly when conditions are worst. A family with no debt can survive a job loss with dignity and time. That breathing room is worth more than almost anything the borrowed money bought.",
          "10. Don't predict Black Swans — prepare for them. Nobody predicted the pandemic, the 2008 crash, or the next crisis either, and nobody will. Prediction is a trap; preparation is a strategy. You prepare with the barbell: reserves on the safe end, optionality in your skills, and no exposure that can ruin you. The next shock is coming. You do not need to know its name.",
          "11. Practice Stoic downside protection. The Stoics rehearsed worst-case scenarios — premeditatio malorum — not to be gloomy but to be free. Taleb points out that Seneca, history's great Stoic, was also one of its richest men: he enjoyed his wealth fully because he had rehearsed losing it. Run the thought experiment before every big commitment. If the worst case happened, what exactly would my next twelve months look like? If you can answer calmly, you can proceed with courage.",
          "12. Subtract before you add — via negativa. We know what is wrong with more confidence than what is right, so improvement often comes from removal. In money: remove high-interest debt, remove fees, remove complexity you cannot explain. In health: remove smoking, remove the midnight sugar, before adding supplements and optimization. In your week: remove the toxic meeting before adding a productivity app. Subtraction is the most underrated strategy in self-improvement.",
        ],
      },
      {
        heading: "Career and work",
        paragraphs: [
          "13. Be a tinkerer, not a planner. Taleb credits most real progress — from the Wright brothers to countless businesses — to bottom-up trial and error, not top-down plans. Ten-year career plans are fragile fantasies; the world changes too fast. Try small things cheaply, keep what works, drop what doesn't. My own path to building this platform was tinkering — write, publish, learn, repeat — not a master plan.",
          "14. Value skin in the game. Trust advice from people who pay a price when they are wrong. The consultant who recommends a strategy and leaves before the results, the guru selling a course on riches he never made — no skin, no signal. Taleb made his own fortune betting his own capital on these ideas, which is part of why practitioners respect him. Apply it as a filter on everyone who advises you, including me: watch what people risk, not what they say.",
          "15. Let small failures teach you. Failure is information, and the tuition is cheapest when the failure is small. A writer who publishes fifty short essays learns what resonates before writing a book; the one who labors ten years on a single manuscript in silence is betting everything on one roll. Ship small, learn fast, adjust. This is why I publish essays here before the book — every reader reaction is data.",
          "16. Beware jobs that look stable but hide fragility. A single employer with a single salary, in an industry slowly declining, is the medium-risk middle of careers — comfortable until the day it is not. The antifragile career builds options: transferable skills, a network across industries, a small side income. You do not need to quit your job; you need to make sure your job is not your only door.",
          "17. Subtract your way to a better career. Via negativa at work: remove the meetings that produce nothing, the commitments that drain you, the clients who cost more than they pay. Careers are often improved less by adding new opportunities than by clearing space for the good ones already knocking.",
        ],
      },
      {
        heading: "Health and the body",
        paragraphs: [
          "18. Your body is antifragile — train it with varied stress. Muscles, bones, and the immune system all strengthen through small, controlled stress followed by recovery. Varied, irregular exercise — lifting, walking, sport, climbing stairs — builds more functional resilience than a rigid routine your body has fully adapted to. Comfort, applied constantly, is the fragilizer.",
          "19. Use intermittent stressors. Hormesis is the principle that a dose of stress triggers repair: occasional fasting prompts cellular cleanup, cold and heat exposure train resilience. You do not need extremes — skipping breakfast sometimes, a brisk walk in cold weather, a hot bath. The ancestors did not eat three scheduled meals a day plus snacks; the body keeps older rhythms than the refrigerator.",
          "20. Beware unnecessary intervention — iatrogenics. Taleb's warning: intervening when you shouldn't often causes more harm than doing nothing. Antibiotics for a virus, medication for every ordinary sadness, a financial product for every ordinary situation — the intervention has side effects the inaction did not. The rule: intervene when the stakes are high, wait when they are low. And of course, for real illness, see a real doctor — Taleb's point is against needless meddling, not against medicine.",
          "21. Eat what time has tested. Traditional diets — the Mediterranean table, fermented foods, simple whole ingredients — survived millennia of trial and error across generations. The newest optimized diet trend has survived one marketing cycle. Lindy applies to the plate: if your great-grandmother would recognize it as food, it has passed a longer stress test than any study.",
        ],
      },
      {
        heading: "Relationships and society",
        paragraphs: [
          "22. Build a redundant, diverse network. Depending on one tight circle — only work friends, only one community — is fragile: a layoff or a falling-out cuts every thread at once. Diverse, loosely connected networks are antifragile; a shock in one area opens doors in another. For immigrants this is doubly important: our home-community bonds are precious, and new bonds across industries and neighborhoods are how opportunities travel.",
          "23. Let criticism strengthen you. Information is antifragile — attempts to suppress it often spread it, and attempts to defend a reputation often wreck it. When your work is criticized, absorb what is true, ignore what is noise, and never wrestle in the mud. Every piece of honest criticism you survive without crumbling makes the next one easier.",
          "24. Don't overprotect the children. A child shielded from every loss, bad grade, and playground conflict becomes an adult who shatters at the first real one. Controlled hardship — losing a game, earning a thing, resolving a dispute — is the vaccine schedule of character. Our parents' generation understood this by necessity; comfort makes us forget it. Let the kids struggle a little. It is love, not neglect.",
        ],
      },
      {
        heading: "The one posture",
        paragraphs: [
          "25. Stop trying to control uncertainty — structure your life so uncertainty helps you. This is the deepest lesson, the one the other twenty-four serve. You cannot predict the economy, the job market, or next year. But you can build a life where the worst case is survivable and the best case is transformative: reserves at the safe end, small bets at the risky end, skills and options collected patiently, nothing that can end the game.",
          "That is the posture I am building toward, and the one this whole site exists to teach. If you take only a handful of these twenty-five, take these: sort by the triad, barbell your money, never accept ruin, subtract before you add, and trust what has survived. The wind is coming either way. Build the fire.",
        ],
      },
      {
        heading: "Sources and further reading",
        paragraphs: [
          "All twenty-five lessons are drawn from Nassim Nicholas Taleb, Antifragile: Things That Gain from Disorder (2012) — the barbell and optionality in Book IV, via negativa and iatrogenics in Book VII, the Lindy effect scattered throughout. Skin in the Game (2018) expands lesson 14 into a full book. For the Stoic foundation, Seneca's Letters from a Stoic. My two companion essays on this site — 'Stronger From the Storm' on the core idea, and 'The Barbell' on the money strategy — go deeper on each theme.",
        ],
      },
    ],
  },
  {
    slug: "what-is-money-history",
    title: "What Is Money, Really? A 5,000-Year Story Every Immigrant Should Know",
    excerpt:
      "From clay tablets in Mesopotamia to Bitcoin — how money is actually created today, why inflation quietly taxes your savings, and why hard assets like real estate, gold, stocks and Bitcoin protect newcomers better than cash ever will.",
    category: "Money",
    date: "May 23, 2026",
    readTime: "16 min",
    art: "shield",
    body: [
      {
        paragraphs: [
          "Here is a question that sounds childish until you try to answer it: what is the money in your bank account? Not what does it buy — what is it? It isn't gold. It isn't backed by gold, or silver, or anything you can touch. It is a number in a database, created by institutions, valuable only because everyone agrees it is valuable. Understanding this — really understanding it — is the single most important financial lesson a newcomer to the West can learn, because it explains why the strategy of 'work hard and hoard cash' is quietly guaranteed to make you poorer.",
        ],
      },
      {
        heading: "A five-minute history of money",
        paragraphs: [
          "Money began as a solution to an awkward problem: barter requires a 'double coincidence of wants' — I have grain and want shoes, you have shoes and want grain. Around 3000 BC, Mesopotamian temples solved this with clay tablets recording debts in barley and silver; the shekel was originally a unit of weight, not a coin. Around 600 BC, the kingdom of Lydia (modern Turkey) minted the first standardized coins, and money became portable. China took the next leap: by the Tang and Song dynasties, paper money circulated — value printed on mulberry bark, accepted because the state said so.",
          "For most of history, paper money was a claim on metal: you could, in theory, redeem it for gold. After World War II, the 1944 Bretton Woods agreement anchored world currencies to the US dollar, and the dollar to gold at $35 an ounce. Then, on August 15, 1971, President Nixon closed the gold window. From that day, no major currency on earth has been backed by anything physical. Every dollar, euro, and Canadian dollar since is fiat money — money by decree, devoid of hard-asset backing, held up entirely by trust and law.",
        ],
      },
      {
        heading: "How money is actually created today",
        paragraphs: [
          "Most people imagine a government printing press. The reality is stranger. Central banks (the Federal Reserve, the Bank of Canada) create base money — but the majority of money in the economy is created by ordinary commercial banks, every time they issue a loan. When a bank approves your mortgage, it doesn't lend out someone's savings; it types new numbers into your account. New money, born as debt. Economists call this credit creation, and it's why the money supply expands relentlessly over time.",
          "In crises, central banks add their own waves: after 2008 and again in 2020, 'quantitative easing' created trillions of new dollars electronically to buy bonds. More money chasing roughly the same amount of goods and assets has one predictable consequence — each unit of money buys less. That is inflation, and it is not an accident of the system. It is a feature of it.",
        ],
      },
      {
        heading: "Inflation: the tax nobody votes on",
        paragraphs: [
          "Purchasing power is what your money actually buys, and it melts like ice in the sun. At 3% annual inflation — roughly the long-run Western average — $10,000 kept in a checking account loses about a quarter of its purchasing power in ten years and nearly half in twenty-five. You can verify this against your own memory: compare the price of groceries, rent, or a car today with ten years ago. The number in the account stayed the same; the life it buys shrank.",
          "For immigrants, this lesson arrives with extra force — and a cruel twist. Many of us come from countries where inflation was violent and obvious, so we learned to hold strong foreign currency as protection. 'Dollars in the mattress' was wisdom back home. But in a country whose currency is the stable one, hoarding that same currency means volunteering for the slow leak. Cash feels safe because its number never falls. Its value falls every single day.",
        ],
      },
      {
        heading: "Hard assets, explained simply",
        paragraphs: [
          "The escape from the leak is to own things whose value rises as money is created — hard assets. Think of it this way: when central banks print, the printer makes more dollars, but it cannot make more land, more gold, more great companies, or more Bitcoin. Scarcity is the whole game. Real estate is shelter plus land — finite, useful, and rentable; as money supply grows, both the property and the rent it commands tend to rise. Gold is humanity's 5,000-year-old insurance policy: it pays no interest and builds nothing, but no government can print it, which is why central banks themselves hoard it.",
          "Stocks are the most powerful hard asset of all, though people rarely call them that: a share is partial ownership of a real business — factories, software, brands, cash flows — and great businesses raise prices with inflation, passing the melt through to you as the owner. And Bitcoin, born in 2009 in direct response to the bank bailouts, is the first digitally scarce asset: only 21 million will ever exist, enforced by code rather than promises. It is volatile — brutally so — and should be sized accordingly, but its thesis is the same as gold's, updated for the internet age.",
        ],
      },
      {
        heading: "Why this serves immigrants better than cash",
        paragraphs: [
          "The newcomer who keeps everything in cash is running two risks at once: the certain, slow loss to inflation, and the missed compounding of decades. The newcomer who converts surplus cash into hard assets — a broad halal index fund of productive companies (SPUS tracks large American companies screened for Islamic compliance), a first home when the numbers make sense, perhaps a measured allocation to gold or Bitcoin — owns things the printing press cannot dilute. Cash has exactly one job in this system: your emergency fund and short-term needs, kept in a riba-free Islamic savings account where any return comes as profit-sharing, not interest. Everything beyond that should be working in assets.",
          "This is not speculation; it is the rational response to how money is actually made. The system rewards owners and quietly taxes holders. Once you see the 5,000-year pattern — every fiat currency in history has been debased, every scarce asset has outlived it — the decision stops being scary and starts being obvious. This thesis runs through everything I write here, and it is a cornerstone of the book I'm finishing now. Learn the rules of the new country, and the new country's system starts working for you.",
        ],
      },
      {
        heading: "Sources and further reading",
        paragraphs: [
          "Felix Martin, Money: The Unauthorised Biography (2013) — the clearest account of money as a social technology of trust. Niall Ferguson, The Ascent of Money (2008) — financial history from Mesopotamia to the mortgage crisis. Carmen Reinhart & Kenneth Rogoff, This Time Is Different (2009) — eight centuries of currency debasement and crisis. The Federal Reserve, The Fed Explained — how central banking and credit creation work today. Saifedean Ammous, The Bitcoin Standard (2018) — the hard-money case for Bitcoin; read critically, but read it. And the Federal Reserve Bank of St. Louis (FRED) — free data to watch purchasing power decline with your own eyes.",
        ],
      },
    ],
  },
  {
    slug: "investing-101-graham-felix",
    title: "Investing 101: The Intelligent Investor's Rules, Proven by Modern Evidence",
    excerpt:
      "Benjamin Graham wrote the bible of investing in 1949. Ben Felix, CIO of PWL Capital, has spent a career testing its lessons against decades of data. Together they form the most honest investing education available — and it's free.",
    category: "Investing",
    date: "May 11, 2026",
    readTime: "16 min",
    art: "chart",
    body: [
      {
        paragraphs: [
          "If you read one investing book in your life, make it The Intelligent Investor by Benjamin Graham — Warren Buffett calls it 'by far the best book on investing ever written.' And if you watch one YouTube channel, make it Common Sense Investing by Ben Felix, Chief Investment Officer and portfolio manager at PWL Capital in Canada, and co-host of the Rational Reminder podcast. Graham published his masterpiece in 1949; Felix has spent his career checking whether its lessons survived seventy-five years of data. The remarkable answer: almost all of them did.",
          "This essay combines both into a complete Investing 101 — written for the person who has their emergency fund in place, their debts under control, and is now staring at a brokerage app wondering what on earth to do next.",
        ],
      },
      {
        heading: "Rule one: meet Mr. Market",
        paragraphs: [
          "Graham's most famous invention is an allegory. Imagine you own a small share of a business, and every day your partner, Mr. Market, knocks on your door offering to buy your share or sell you his — at a different price each time. Some days he's euphoric and quotes a ridiculous high; some days he's terrified and quotes a panic low. His secret: you are free to ignore him completely. He will come back tomorrow with a new number regardless.",
          "The stock market is Mr. Market. Prices swing on fear and greed in the short run, but in the long run they follow what businesses actually earn — Graham's line is that the market is a voting machine in the short term and a weighing machine in the long term. The investor's job is to use Mr. Market's moods, not be infected by them. For a newcomer who has lived through real economic collapse, this is the crucial reframe: a falling market is a moody partner offering you a discount, not a building on fire.",
        ],
      },
      {
        heading: "Rule two: the margin of safety",
        paragraphs: [
          "Graham's central concept, in his own words the secret of sound investment: always leave a margin of safety. Buy for less than something is worth, diversify so no single failure can ruin you, and never take a risk whose bad outcome ends your game. Forecasts will be wrong — the margin of safety is what saves you when they are.",
          "For the ordinary investor, the modern translation is simple: don't bet everything on one stock, one sector, or one country. Own hundreds of companies across the world through low-cost halal index funds — SPUS and HLAL hold the market while screening out businesses that fail Islamic compliance — keep your emergency fund separate so you're never forced to sell in a crash, and let time do the compounding. Graham called the person who does this the 'defensive investor' — and said their results, achieved with 'a minimum of effort and capability,' would shame most professionals.",
        ],
      },
      {
        heading: "Rule three: the evidence — stock picking and market timing don't work",
        paragraphs: [
          "This is where Ben Felix's work becomes devastating. Decade after decade, the data says the same thing: the vast majority of professional fund managers — full-time experts with research teams — fail to beat a simple low-cost index fund over long periods. The S&P's SPIVA scorecards track this across every major market, and the longer the window, the worse the professionals look. Fees are a big reason: a fund charging 2% annually must beat the market by 2% just to tie it, and compounding turns that handicap into a fortune over a working life.",
          "Felix's research summaries make the same point about timing: missing just a handful of the market's best days — which cluster right after its worst days, when fear is highest — destroys long-term returns. His conclusion, backed by a century of evidence: you cannot beat the market reliably, and you don't need to. Own the whole market at the lowest possible cost, keep contributing automatically, and spend your energy on your career and family instead of on forecasts.",
        ],
      },
      {
        heading: "Rule four: what to actually buy",
        paragraphs: [
          "Graham suggested the defensive investor split between stocks and high-quality bonds and rebalance occasionally. For the Muslim investor, the halal counterpart of that bond portion is sukuk — asset-backed certificates that pay profit from real assets rather than interest — now available through ordinary sukuk funds and ETFs, so the defensive mix stays fully Sharia-compliant. Felix's modern version: a globally diversified portfolio of low-cost index ETFs — thousands of companies across the US, Canada, developed and emerging markets — held inside tax-sheltered accounts (TFSA/RRSP in Canada, 401(k)/IRA in the US). His model portfolios add small tilts toward factors that academic research — the Fama-French five-factor model — has shown to raise long-run returns: smaller companies, value stocks, and profitable firms. The tilts are optional refinement; the diversification and low cost are the non-negotiables.",
          "Two of his practical lessons deserve special mention for newcomers. First, his famous '5% Rule' video on renting versus buying: a home is not automatically the best investment — run the numbers before assuming otherwise. Second, behavior beats strategy: the best portfolio is the one you can hold through a 30% crash without selling. Choose boring enough to sleep with.",
        ],
      },
      {
        heading: "The immigrant's starting checklist",
        paragraphs: [
          "Putting it all together: build your emergency fund first (Graham's margin of safety, in cash form). Grab any employer retirement match — an instant, guaranteed return. Open your tax-sheltered account. Set an automatic contribution into one globally diversified, low-cost index ETF. Then ignore Mr. Market's daily moods, review once a year, and let the weighing machine work.",
          "That's it. The most honest conclusion in all of investing is that the optimal strategy fits in a paragraph — Graham intuited it in 1949, and Felix's evidence has been confirming it ever since. The industry profits from making it look complicated; the wealth comes from keeping it simple. This framework — mindset, savings rate, and now evidence-based investing — is the backbone of the book I'm writing for newcomers. The best free education in finance already exists; this essay is your map to it.",
        ],
      },
      {
        heading: "Sources and further reading",
        paragraphs: [
          "Benjamin Graham, The Intelligent Investor (revised edition with Jason Zweig's commentary, 2003) — chapters 8 (Mr. Market) and 20 (margin of safety) are the essentials. Ben Felix, Common Sense Investing on YouTube and the Rational Reminder podcast — start with 'Investing 101,' 'The 5% Rule,' and 'Five Factor Investing with ETFs.' Eugene Fama & Kenneth French — the academic research behind factor investing. S&P Dow Jones Indices, SPIVA Scorecards — the running score of active managers versus index funds. John Bogle, The Little Book of Common Sense Investing — the index fund case from the man who invented it. For halal implementation: the SPUS and HLAL fund pages from their providers, sukuk fund prospectuses, and the AAOIFI Sharia screening standards that define what counts as compliant.",
        ],
      },
    ],
  },
  {
    slug: "newcomers-money-routine",
    title: "The Newcomer's Money Routine: Three Books, One System",
    excerpt:
      "The Psychology of Money fixes your risk instincts. Meet the Frugalwoods fixes your savings rate. The Wealthy Barber fixes your systems. Here's how I combine all three into a weekly, monthly, and yearly routine for immigrants building wealth in the West.",
    category: "Newcomers",
    date: "Apr 29, 2026",
    readTime: "14 min",
    art: "steps",
    body: [
      {
        paragraphs: [
          "Over the past three essays I've written about three books that shaped how I think about money: Morgan Housel's The Psychology of Money, Liz Thames's Meet the Frugalwoods, and David Chilton's The Wealthy Barber. People often ask which one they should read. My honest answer is that the question misses the point — these books aren't competitors. They're three parts of one machine.",
          "This matters especially if you arrived in America, Canada, or another Western country from a poorer one. The money instincts you developed back home were not wrong — they were rational responses to high inflation, unstable banks, and currencies that could evaporate. But instincts that kept you safe there can quietly keep you poor here. Rebuilding those instincts requires three different repairs, and each book handles one.",
        ],
      },
      {
        heading: "Three engines, one machine",
        paragraphs: [
          "In my reading notes I call them the three engines. The Psychology of Money is the behavioral engine: it repairs how you perceive risk, so that a falling market reads as a fee for future returns rather than a fire alarm. Meet the Frugalwoods is the operational engine: it maximizes the gap between what you earn and what you spend, because in your early years your savings rate — not your investment genius — is the primary engine of capital. The Wealthy Barber is the structural engine: it installs the automatic plumbing — pre-authorized contributions, tax-sheltered accounts, dollar-cost averaging — that keeps wealth building even when your motivation takes a month off.",
          "Mind, gap, system. Behavior tells you why to invest, frugality gives you something to invest, and automation makes sure it actually happens. Remove any one engine and the machine stalls: mindset without savings is theory, savings without automation leaks, and automation without mindset gets switched off at the first market crash.",
        ],
      },
      {
        heading: "The weekly habit: twenty minutes on Sunday",
        paragraphs: [
          "Once a week — I do it Sunday evening — sit down with your banking app for twenty minutes. Two questions only. First: did my spending this week roughly match my plan? Second: what needs adjusting next week? No guilt, no forensic accounting, no spreadsheets with nineteen tabs.",
          "While you're there, ask the Frugalwoods question about your two or three biggest purchases: did this buy me freedom, or did it cost me freedom? You won't always like the answer, and that's fine. The goal isn't a perfect record — it's keeping the gap between income and spending visible. What gets seen gets managed.",
        ],
      },
      {
        heading: "The monthly habit: know your savings rate",
        paragraphs: [
          "On the first weekend of each month, calculate one number: what percentage of your take-home pay did you keep? Not what you intended to keep — what you actually kept. Write it down somewhere dumb and simple. A note on your phone works.",
          "Then do one optimization. Just one. Cancel a subscription you forgot. Renegotiate your phone plan. Cook the meal you usually order. The Frugalwoods insight is that these cuts are tax-free raises — a dollar saved is worth more than a dollar earned, because the earned dollar gets taxed on the way in. Twelve small optimizations a year compound into a permanently wider gap.",
        ],
      },
      {
        heading: "The quarterly habit: turn the ratchet",
        paragraphs: [
          "Every three months, raise your automatic investment transfer — even by 1% of your income. This is the Wealthy Barber's ratchet: the transfer only moves in one direction. Because the money leaves before you see it, your lifestyle never expands to swallow the increase. Four small raises a year means your savings rate climbs almost painlessly while your life stays the same.",
          "Use the same check-in to learn one piece of your new country's financial infrastructure. This quarter: how a TFSA or Roth IRA actually works. Next quarter: what your employer match is really worth. The quarter after: how your credit score is built. None of this is taught anywhere — it's tribal knowledge that locals absorb by osmosis, and newcomers have to hunt down deliberately.",
        ],
      },
      {
        heading: "The annual habit: the net worth letter",
        paragraphs: [
          "Once a year — I do it every December — write yourself a one-page letter. List your assets, list your debts, subtract, and write down your net worth. Then answer Housel's question: when the market dropped this year, did I panic, or did I treat it as the fee? And Thames's question: is my lifestyle inflation under control, or did the arrival effect catch me? And Chilton's question: did my automatic system run all twelve months without me touching it?",
          "That letter, reread in future years, becomes the most motivating document you own. Watching the number climb from negative to zero to five figures to six is proof — in your own handwriting — that the machine works.",
        ],
      },
      {
        heading: "The traps that are specific to us",
        paragraphs: [
          "A few traps hit newcomers harder than anyone else, and the routine should name them. Cash hoarding: keeping everything in a checking account feels safe if you grew up watching banks fail, but in a stable economy inflation is the quiet thief — your emergency fund belongs in a riba-free account (an Islamic bank's profit-sharing savings pays you without interest), and everything beyond it belongs in halal investments. The arrival effect: your first Western paycheck feels enormous, and lifestyle inflation can consume the entire critical first five years — the window when your savings rate matters most. Family obligations: remittances are real and honorable, so don't pretend they don't exist — give them a fixed line in your budget, a number you choose in advance, so generosity doesn't silently eat the engine.",
          "And a warning: our communities are specifically targeted by get-rich-quick schemes, forex 'mentors,' and crypto promises, precisely because scammers know we're hungry and the system is unfamiliar. The routine above is slower. It is also the one that actually works — every genuinely wealthy immigrant family I know built it this way, never the other way.",
        ],
      },
      {
        heading: "What's next",
        paragraphs: [
          "This three-engine framework is the skeleton of the book I'm writing now — a complete, step-by-step system for newcomers building wealth in the West, from your first paycheck to your first six figures. It expands each habit here into full chapters, with the worksheets and account-by-account walkthroughs I wish someone had handed me. Join the newsletter and you'll be the first to know when it launches — and until then, these four essays are the bedrock. Start anywhere, but start.",
        ],
      },
    ],
  },
  {
    slug: "wealthy-barber-lessons",
    title: "The Barber Who Retired Rich on a Barber's Income",
    excerpt:
      "David Chilton's The Wealthy Barber teaches money through a Sarnia barbershop — and its hero proves that wealth is about systems, not salary. His 10% rule is still the simplest wealth-building machine ever written down.",
    category: "Books",
    date: "Apr 17, 2026",
    readTime: "11 min",
    art: "coin",
    body: [
      {
        paragraphs: [
          "The most financially successful character in The Wealthy Barber is not a banker, a doctor, or a tech founder. He's Roy, a barber in Sarnia, Ontario, who cuts hair for a living — and quietly became wealthy doing it. David Chilton's classic teaches personal finance as a story: three young people keep returning to Roy's barbershop for lessons, and over the years the reader gets educated alongside them.",
          "The premise alone is worth the price of the book. If a man on a barber's income can retire comfortably, then income was never the binding constraint. The system was. And systems, unlike salaries, are available to everyone on day one — including the newcomer who just landed their first job in a new country.",
        ],
      },
      {
        heading: "The 10% rule",
        paragraphs: [
          "Roy's central lesson fits in one sentence: save ten percent of everything you earn, before you spend anything, and invest it for the long term. Pay yourself first. Not what's left after the month — the month gets what's left after the saving. Chilton understood something most finance books miss: the order of operations is the entire trick. Money that touches your checking account gets spent; money that never arrives there gets kept.",
          "Ten percent is a starting point, not a ceiling — but it's a remarkably effective one. Invested steadily into broad equity funds over a working life, a tenth of even a modest income compounds into genuine security. The barber's wage is the proof: small, consistent, automated beats large, irregular, and intended.",
        ],
      },
      {
        heading: "Automate it, or it won't happen",
        paragraphs: [
          "The book's most practical insight is that willpower is not a plan. Roy doesn't tell his students to 'remember to save' — he tells them to set up a pre-authorized contribution that moves the money on payday, automatically, before they can touch it. Human inertia, usually the enemy, gets drafted onto your side: the default becomes saving, and spending requires the effort.",
          "The companion idea is dollar-cost averaging: investing the same amount on a fixed schedule regardless of what the market is doing. You buy more shares when prices are low and fewer when they're high, and you never have to predict anything. For newcomers especially, this is liberating — you don't need to understand the market to benefit from it. You need a transfer that runs every two weeks and the discipline to leave it alone.",
        ],
      },
      {
        heading: "Use the accounts your new country gives you",
        paragraphs: [
          "Chilton wrote for Canadians, and the book walks through tax-sheltered accounts — RRSPs and their cousins — in unusual detail. The principle generalizes to every Western country: the government offers accounts where investment growth is sheltered from tax, and not using them is voluntarily paying more tax than the law requires. In Canada that's the TFSA and RRSP; in the US, the 401(k) and IRA; other countries have their equivalents.",
          "Here's the part that matters for immigrants: nobody tells you these accounts exist. There's no orientation packet, no welcome letter. Colleagues who grew up here absorb it from parents and coworkers; you have to go find it. And if your employer offers a retirement match, enrolling is the single highest-return financial decision available to you — it's an instant, guaranteed return that no investment can beat. The Wealthy Barber was written before low-fee index ETFs existed, so update the vehicles — but the architecture is timeless: automatic contributions, tax-sheltered accounts, broad diversified funds, decades of patience.",
        ],
      },
      {
        heading: "What I took from it",
        paragraphs: [
          "Two sentences from this book live rent-free in my head. First: wealth is what you keep, not what you earn — measure your net worth, not your paycheck. Second: the best financial plan is the one that runs without you. Every system I build for myself and recommend to readers — automatic transfers, payday timing, the quarterly ratchet — is descended from Roy's barbershop.",
          "Read it after The Psychology of Money and Meet the Frugalwoods, and you'll have the complete machine: the mindset to stay invested, the gap to fund it, and the plumbing to make it permanent. It's also the framework at the heart of the book I'm writing for newcomers — because a barber in Sarnia proved, decades ago, that the system matters more than the salary.",
        ],
      },
    ],
  },
  {
    slug: "meet-the-frugalwoods-lessons",
    title: "The Couple Who Saved 70% of Their Paychecks",
    excerpt:
      "Liz Thames and her husband walked away from corporate life in their early thirties by doing one thing extraordinarily well: keeping the gap between earning and spending enormous. What Meet the Frugalwoods gets right — and how to adapt it without moving to the woods.",
    category: "Books",
    date: "Apr 5, 2026",
    readTime: "11 min",
    art: "bars",
    body: [
      {
        paragraphs: [
          "Liz Thames had the life the script promised: a good degree, a corporate job, a nice apartment in Cambridge, Massachusetts, dinners out, the whole conveyor belt. And she was quietly miserable. Meet the Frugalwoods is the story of how she and her husband Nate looked at that script, declined it, and instead saved an astonishing share of their income — at their peak, over 70% — until they could walk away from their jobs in their early thirties and move to a homestead in the Vermont woods.",
          "You do not need to want a Vermont homestead for this book to change your life. The homestead is their dream; the machinery underneath it works for any dream — including the most common one I hear from newcomers: 'I want my family to be safe, and I never want to feel trapped by money again.'",
        ],
      },
      {
        heading: "The only number that matters early on",
        paragraphs: [
          "The book's core insight is almost offensively simple: in the early years, your savings rate matters more than your investment returns. When your portfolio is small, a brilliant 12% return adds less than a mediocre month of aggressive saving. Compounding is a rocket, but savings rate is the fuel truck — and the rocket doesn't launch until the tank has something in it.",
          "Thames's second insight is economic: cutting a dollar of spending is worth more than earning a dollar more, because the saved dollar arrives tax-free while the earned dollar gets clipped by taxes on the way in. Every expense you eliminate is a permanent, untaxed raise. That's why the Frugalwoods treated their budget not as a list of restrictions but as the single most powerful lever they controlled.",
        ],
      },
      {
        heading: "The arrival effect",
        paragraphs: [
          "Here's where the book becomes essential reading for immigrants specifically. When you arrive from a poorer country and receive your first paycheck in dollars or Canadian dollars, the number feels enormous — because back home, it would be. What follows is a trap I've watched swallow entire families: the apartment gets upgraded, the car gets financed, the restaurant visits multiply, and within two years the 'enormous' salary is fully consumed by an enormous lifestyle. I call it the arrival effect, and it quietly destroys the most valuable years a newcomer has.",
          "Those first five years are your capital-formation window — the period when a high savings rate builds the principal that compounding will later multiply. Thames's lesson, translated for newcomers: you already know how to live on less, because you or your parents did it back home. That skill, which the culture around you may have lost, is a genuine competitive advantage. Don't trade it away in your first years here.",
        ],
      },
      {
        heading: "Frugality is not deprivation",
        paragraphs: [
          "The lazy reading of this book is 'never buy anything, eat rice, be miserable.' Thames says the opposite. The Frugalwoods method is strategic non-consumption: cut ruthlessly the things you don't care about so you can keep — or even expand — the things you love. They kept what mattered to them and eliminated what Thames calls the leak: convenience spending, status spending, default spending. The question was never 'can I afford this?' but 'does this buy me freedom, or cost me freedom?'",
          "I'll also give you the honest critique, because you deserve it: the Thameses had high dual incomes, and extreme savings rates are easier on large salaries. Don't copy their percentages — copy their direction. If you keep 15% while your coworkers keep 2%, the machine works. Widen the gap at whatever speed your life allows, and widen it a little more every year.",
        ],
      },
      {
        heading: "What I took from it",
        paragraphs: [
          "Three things. Track your savings rate monthly — it's the one number that predicts your future better than your salary does. Treat lifestyle inflation as the enemy it is, especially in the arrival years. And remember that frugality done right is not about having less — it's about buying your freedom back, one un-bought thing at a time.",
          "In the three-engine framework I use — and expand in my upcoming book — this is the operational engine: the part that manufactures the fuel. Next up: the structural engine, from a wealthy barber in Ontario.",
        ],
      },
    ],
  },
  {
    slug: "psychology-of-money-lessons",
    title: "The Janitor Who Died a Millionaire",
    excerpt:
      "Ronald Read fixed cars and swept floors; Richard Fuscone had a Harvard MBA and a Wall Street career. Only one of them died wealthy. The Psychology of Money explains why — and why it matters twice as much if you grew up somewhere unstable.",
    category: "Books",
    date: "Mar 24, 2026",
    readTime: "12 min",
    art: "wave",
    body: [
      {
        paragraphs: [
          "Ronald Read spent his career as a gas station attendant and janitor in Vermont. He died in 2014 with over $8 million, which he left to his local library and hospital. Richard Fuscone was a Harvard-educated Merrill Lynch executive who went bankrupt in the 2008 financial crisis, surrendering his mansion to the bank. Morgan Housel opens The Psychology of Money with these two lives for a reason: financial success is not a hard science. It's a soft skill — and behavior beats intelligence almost every time.",
          "Of all the money books I've read, this is the one I hand to people first — especially friends who, like me, started their financial lives in countries where the rules were different. Because the book isn't really about money. It's about the stories we carry in our heads about money, and how those stories can be perfectly rational and completely wrong at the same time.",
        ],
      },
      {
        heading: "Everyone's money instincts were earned somewhere",
        paragraphs: [
          "Housel's first big idea: no one is crazy. Everyone's financial behavior is anchored to the economy they grew up in. If you came of age during high inflation, you learned that cash is trash and money must be spent fast. If you watched a bank collapse or a currency devalue, you learned that institutions cannot be trusted and savings must be hidden, movable, and close. These aren't foolish beliefs — they were survival skills, earned the hard way.",
          "But here's the immigrant's dilemma: the instincts that protected you in an unstable economy become liabilities in a stable one. Hoarding cash 'just in case' means inflation quietly eats 3% of it every year. Refusing to invest because 'the market is a casino' means missing the single most reliable wealth-building machine ordinary people have ever had access to. The first work of building wealth in the West isn't opening an account — it's recognizing that your risk instincts were calibrated for a different country.",
        ],
      },
      {
        heading: "Volatility is a fee, not a fine",
        paragraphs: [
          "The single most valuable sentence in the book, for me: view market volatility as a fee, not a fine. A fine is a punishment for doing something wrong — it makes you want to stop. A fee is the price of admission for something worth having. The stock market's long-term returns are not free; the price is enduring regular, stomach-turning drops without selling. Investors who treat a 20% decline as a fine sell at the bottom and lock in the loss. Investors who treat it as a fee hold on and collect the return.",
          "This reframing is everything for newcomers. When you've lived through real economic collapse, a market dip doesn't feel like a fee — it feels like the beginning of the thing you've seen before. It isn't. A diversified index fund in a stable economy recovering from a crash is a pattern with a century of evidence behind it. Your fear is understandable. It is also expensive.",
        ],
      },
      {
        heading: "Survival first, returns second",
        paragraphs: [
          "Housel's other great theme is what he calls room for error. Getting rich and staying rich are different skills: getting rich requires taking risks and being optimistic; staying rich requires humility and fear — the fear that everything you've built can be taken away. The plan that survives is the one with a margin of safety: an emergency fund, no ruinous leverage, no bet so large that a bad outcome ends the game.",
          "Because — and this is the tail-events idea — most of what happens in markets and in life is driven by a small number of extreme events. You don't need to be right often. You need to avoid the one catastrophic loss that forces you out of the game entirely. A janitor became a millionaire not by being brilliant, but by buying good companies and never, ever being forced to sell. Survival is the strategy.",
        ],
      },
      {
        heading: "What I took from it",
        paragraphs: [
          "Three sentences I return to constantly. Freedom is the highest dividend money pays — the goal isn't stuff, it's control over your time. Save without a specific reason — the savings that save you are the ones you didn't earmark. And define 'enough' before the world defines it for you — the hardest financial skill is getting the goalpost to stop moving.",
          "In the three-engine framework I use with readers — and expand in my upcoming book — this book is the behavioral engine: it repairs how you see risk. Next in the series: the operational engine, from a couple who saved 70% of their income and retired to the woods.",
        ],
      },
    ],
  },
  {
    slug: "pay-yourself-first",
    title: "The Quiet Power of Paying Yourself First",
    excerpt:
      "Most people save what's left after spending. The people who build wealth spend what's left after saving. Here's how to flip the equation — automatically.",
    category: "Saving",
    date: "Mar 12, 2026",
    readTime: "6 min",
    art: "coin",
    body: [
      {
        paragraphs: [
          "There is a sentence I hear at least once a week: “I'll start saving when things calm down.” Things never calm down. There is always a birthday, a car repair, a sale, a season. Waiting for a quiet month to save is like waiting for an empty gym at 6pm — theoretically possible, practically never happens.",
          "The fix is not more discipline. It's a different order of operations. Most people run their money like this: income arrives, bills get paid, life gets lived, and whatever remains — usually nothing — goes to savings. Paying yourself first simply reverses the sequence: savings leaves first, and life happens on what remains.",
        ],
      },
      {
        heading: "Make it a bill you owe yourself",
        paragraphs: [
          "The psychological trick is to treat your savings transfer like rent — non-negotiable, due on the same day every month, no exceptions. Set an automatic transfer for the morning after payday. Not the end of the month. Not “when I remember.” The morning after payday, before your brain has time to negotiate.",
          "Start smaller than your ego wants. If you think you can save 20%, start with 10%. A system you keep for twelve months beats an ambitious one you abandon in February. You can raise the rate every quarter — each increase barely registers because your spending never had the chance to expand into that money.",
        ],
      },
      {
        heading: "Where the money should go",
        paragraphs: [
          "Order matters here too. First, a starter emergency fund — even one month of expenses changes how you sleep. Second, any employer retirement match, because declining it is turning down a 100% instant return. Third, high-interest debt. Only then should you think about investing beyond the match or saving for goals.",
          "None of this is exciting. That's the point. Wealth is mostly built by boring systems running quietly in the background while you live your life. Pay yourself first, automate it, and let time do the heavy lifting.",
        ],
      },
    ],
  },
  {
    slug: "first-budget-framework",
    title: "A Simple Framework for Your First Budget",
    excerpt:
      "Forget tracking 47 categories. A budget that works has three numbers, one weekly habit, and enough slack to survive real life.",
    category: "Budgeting",
    date: "Feb 28, 2026",
    readTime: "8 min",
    art: "bars",
    body: [
      {
        paragraphs: [
          "Most budgets fail for the same reason most diets fail: they're built for an imaginary person with infinite willpower and no social life. The spreadsheet has nineteen categories, every dollar is assigned, and by day eleven the whole thing collapses under the weight of one unplanned dinner.",
          "A budget that survives contact with real life is simpler. It has three numbers: what comes in, what must go out, and what's left to decide about. That's it. Everything else is refinement you can add later, once the habit exists.",
        ],
      },
      {
        heading: "The three numbers",
        paragraphs: [
          "Number one: your actual take-home income. Not your salary — the amount that lands in your account. Number two: your fixed obligations. Rent, utilities, debt minimums, insurance, subscriptions. Add them up once; they barely change month to month. Number three: income minus obligations. That remainder is your decision pool — groceries, transport, fun, savings, everything flexible.",
          "Now split the decision pool with intention. A reasonable starting ratio for most households: 60% to living, 30% to future-you (savings, extra debt payments, investing), 10% to a buffer for the stuff you forgot. Adjust the ratio to your reality — the ratio matters less than the fact that you chose it on purpose.",
        ],
      },
      {
        heading: "The weekly ten minutes",
        paragraphs: [
          "The habit that makes this work is a weekly review, not a monthly autopsy. Once a week — Sunday evening works well — open your banking app and compare what you planned against what happened. Ten minutes. No guilt, no spreadsheets with conditional formatting. Just: am I roughly on track, and does next week need an adjustment?",
          "And build in slack on purpose. A budget with zero room for spontaneity is a budget you'll abandon. The buffer category isn't a failure of planning — it's an admission that you're a human being, and human beings occasionally buy the concert tickets.",
        ],
      },
    ],
  },
  {
    slug: "debt-snowball-vs-avalanche",
    title: "Debt Snowball vs. Debt Avalanche: Which One Actually Wins?",
    excerpt:
      "One method is mathematically optimal. The other is psychologically optimal. The right choice depends on which kind of quitting you're prone to.",
    category: "Debt",
    date: "Feb 16, 2026",
    readTime: "7 min",
    art: "steps",
    body: [
      {
        paragraphs: [
          "If you carry multiple debts — a credit card, a car loan, maybe a store card from a moment of weakness — you've probably heard two competing strategies. The avalanche says: attack the highest interest rate first. The snowball says: attack the smallest balance first. Personal finance people argue about this like it matters enormously. It matters less than you think, and more than you'd expect.",
        ],
      },
      {
        heading: "The math, honestly",
        paragraphs: [
          "The avalanche wins on paper. Paying off a 24% credit card before a 6% car loan saves real money — sometimes hundreds or thousands over the life of the debts, depending on your balances. If you ran your finances like a spreadsheet, this would be the end of the discussion.",
          "But you are not a spreadsheet. Research on debt repayment consistently finds that people who close small accounts early are more likely to eliminate their debt entirely. Every account you close is a visible win, and visible wins are fuel. The snowball costs more in interest and works more often in practice.",
        ],
      },
      {
        heading: "How to choose",
        paragraphs: [
          "Ask yourself one question: when a project gets hard and results are invisible, do you push through, or do you drift? If you push through, take the avalanche and keep the savings. If you drift — and most of us drift — take the snowball and don't apologize for it. The best method is the one still running in month nine.",
          "Whichever you pick, the mechanics are identical: minimum payments on everything, every spare dollar aimed at one target, and a small celebration each time a balance hits zero. Then roll that freed-up payment into the next target. That's the part both methods agree on — momentum is the whole game.",
        ],
      },
    ],
  },
  {
    slug: "index-funds-explained",
    title: "Index Funds, Explained Like a Friend Would",
    excerpt:
      "No jargon, no charts with seventeen lines — just a plain explanation of what an index fund is, why the dull option usually wins, and how to actually buy one.",
    category: "Investing",
    date: "Feb 4, 2026",
    readTime: "9 min",
    art: "chart",
    body: [
      {
        paragraphs: [
          "Imagine you want to bet on a horse race, but instead of picking one horse, you buy a tiny slice of every horse in the race. You won't win big — but you also can't lose everything to one lame horse, and you're guaranteed to own a piece of the winner. That's an index fund. It's a single investment that holds small pieces of hundreds or thousands of companies at once.",
          "When people say “the market returned 10%,” they usually mean an index — a list like the S&P 500, which tracks 500 large American companies. An index fund simply buys that list. No manager picking stocks, no genius predictions. Just the whole haystack instead of a search for the needle.",
        ],
      },
      {
        heading: "Why the dull option usually wins",
        paragraphs: [
          "Here's the uncomfortable fact that the finance industry would rather you not dwell on: over long periods, the vast majority of professional stock-pickers underperform the simple index. Not some of them. Most of them. And they're full-time experts with research teams. The reason is costs and humility — every trade has a fee, every forecast has an error rate, and both compound against you.",
          "Index funds flip this. Their fees are tiny — often a tenth of what active funds charge — and they don't pretend to know the future. Over decades, that fee difference alone can translate into six figures of extra retirement money on an ordinary salary. It turns out dull is exactly what you want from your money.",
        ],
      },
      {
        heading: "How to actually start",
        paragraphs: [
          "The mechanics are simpler than the mythology. Open an account with a reputable, low-cost brokerage — ideally inside whatever tax-advantaged retirement account your country offers. Pick a broad, low-fee halal index fund: SPUS — a Sharia-screened version of the S&P 500 — is the classic starting point, and HLAL is a strong global alternative. Both screen out companies whose business (alcohol, gambling, conventional interest-based banking) or debt levels conflict with Islamic principles, so you get the whole haystack without the haram. Set an automatic monthly purchase, even if it's small. Then — this is the hard part — leave it alone.",
          "The market will drop 20% at some point. It will feel terrible. Every long-term investor's returns are partly payment for enduring exactly that feeling without selling. Your plan should be written down before the storm: I buy every month, I don't watch the news, I check in once a year. That's the whole strategy, and it has beaten most clever ones for a century.",
        ],
      },
    ],
  },
  {
    slug: "emergency-fund-that-survives",
    title: "Building an Emergency Fund That Actually Survives Emergencies",
    excerpt:
      "“Three to six months of expenses” is fine advice that's weirdly hard to use. Here's how to size, place, and protect a fund that works when you need it.",
    category: "Saving",
    date: "Jan 23, 2026",
    readTime: "7 min",
    art: "shield",
    body: [
      {
        paragraphs: [
          "The standard advice — save three to six months of expenses — is correct and almost useless. It's like being told to “eat healthy.” Which expenses? Whose three months? And where do you keep this money so it exists when the emergency actually arrives?",
        ],
      },
      {
        heading: "Size it to your life, not a slogan",
        paragraphs: [
          "Start with your survival number: rent or mortgage, utilities, food, transport, insurance, minimum debt payments. Not your current lifestyle — the stripped-down version you'd run if income stopped tomorrow. For most people this is 60–70% of their normal spending, which makes the target less scary than it first appears.",
          "Then adjust for risk. Two incomes, stable industry, no dependents? Three months is plausibly fine. Single income, variable earnings, kids, or a job in a shaky sector? Aim for six or beyond. Freelancers should think in terms of their slowest historical quarter, not their average month.",
        ],
      },
      {
        heading: "Where to keep it (and where not to)",
        paragraphs: [
          "An emergency fund has one job: be there, in full, immediately. That rules out the stock market — emergencies have a rude habit of coinciding with downturns. It also rules out your everyday checking account, where the money quietly dissolves into lifestyle. The right home is a separate riba-free savings account — an Islamic bank's profit-sharing savings account pays you a return without interest, which matters, because riba is not a small thing and your safety money is the last place it belongs. What you need is instant or next-day access and just enough friction that you won't dip into it for a sale.",
          "Finally, define “emergency” in writing before one happens. Job loss, medical bills, urgent repairs: yes. Flights for a wedding, a discounted sofa, a festival ticket: no. The definition feels pedantic until the day it protects you from yourself — which is the day the fund was built for.",
        ],
      },
    ],
  },
  {
    slug: "psychology-of-spending",
    title: "The Psychology of Spending: Why Willpower Isn't the Answer",
    excerpt:
      "You don't have a discipline problem — you have an environment problem. Change the friction, and the behavior follows.",
    category: "Mindset",
    date: "Jan 1, 2026",
    readTime: "6 min",
    art: "wave",
    body: [
      {
        paragraphs: [
          "Every January, millions of people resolve to spend less, and by March most of them are back to baseline. The usual explanation is weak willpower. The better explanation is that willpower was never the right tool. Spending is an environmental behavior: it responds to cues, defaults, and friction far more reliably than to resolve.",
        ],
      },
      {
        heading: "Friction is the real lever",
        paragraphs: [
          "Consider how much engineering goes into making spending effortless. One-click checkout. Saved cards. Push notifications engineered to create urgency. “Only 3 left.” Your spending environment has been professionally optimized — by very smart people — against your intentions. Fighting that with raw discipline is bringing a knife to a gunfight.",
          "So fight with friction instead. Delete saved cards from your browser. Unsubscribe from retail newsletters — all of them, in one ruthless sitting. Institute a 48-hour rule for anything over a set amount: add it to a list, and if you still want it in two days, buy it without guilt. Most wants evaporate; the ones that survive are usually worth it.",
        ],
      },
      {
        heading: "Replace, don't just remove",
        paragraphs: [
          "Pure restriction backfires the way crash diets do. The sustainable version of spending less is spending deliberately: cut hard on what you don't care about so you can spend freely on what you love. The person who adores travel and is indifferent to cars should drive something boring and fly well. Money is a tool for building a life, not a score to maximize.",
          "Track one metric that captures this: your savings rate, reviewed monthly. Not whether each individual purchase was “good” — that way lies madness — but whether the overall flow points toward the life you actually want. Behavior follows measurement, and measurement is easier than virtue.",
        ],
      },
    ],
  },
];

export const EBOOKS: Ebook[] = [
  {
    id: "money-reset",
    title: "The Awdahir Money Reset",
    subtitle: "A 30-day system to take control of your money",
    description:
      "My flagship guide. Thirty days, thirty small actions: audit your accounts, build your first real budget, automate your savings, and set up a system that runs itself. Includes worksheets and checklists.",
    price: "$19",
    pages: "86 pages",
    format: "PDF + worksheets",
    motif: "circle",
    accent: "chart",
    payhipUrl: "https://payhip.com/awdahir",
    badge: "Bestseller",
  },
  {
    id: "debt-free-blueprint",
    title: "Debt-Free Blueprint",
    subtitle: "A step-by-step plan to eliminate what you owe",
    description:
      "From the first honest inventory of every balance to the final zero. Covers snowball vs. avalanche, negotiating rates, staying motivated, and the exact payment-order worksheets I use with clients.",
    price: "$15",
    pages: "64 pages",
    format: "PDF + spreadsheets",
    motif: "stack",
    accent: "mint",
    payhipUrl: "https://payhip.com/awdahir",
  },
  {
    id: "investing-basics",
    title: "Investing Basics Workbook",
    subtitle: "From zero to your first index fund",
    description:
      "A hands-on workbook: what stocks and funds actually are, how fees compound against you, how to open an account, and how to build a simple portfolio you can ignore with confidence. Jargon-free by design.",
    price: "$12",
    pages: "58 pages",
    format: "PDF workbook",
    motif: "arcs",
    accent: "brick",
    payhipUrl: "https://payhip.com/awdahir",
  },
  {
    id: "freelancer-playbook",
    title: "The Freelancer's Finance Playbook",
    subtitle: "Irregular income, made manageable",
    description:
      "For anyone without a steady paycheck: smoothing variable income, the two-account system, quarterly tax planning, pricing your work, and building an emergency fund sized for feast-and-famine cycles.",
    price: "$17",
    pages: "72 pages",
    format: "PDF + templates",
    motif: "grid",
    accent: "chart",
    payhipUrl: "https://payhip.com/awdahir",
    badge: "New",
  },
];

export interface Resource {
  title: string;
  description: string;
  type: "Free download" | "Template" | "Reading list" | "Tool";
  url: string;
}

export const RESOURCES: Resource[] = [
  {
    title: "The One-Page Money Audit",
    description:
      "A printable checklist to map every account, balance, and subscription in under an hour. The starting point I recommend to everyone.",
    type: "Free download",
    url: "https://payhip.com/awdahir",
  },
  {
    title: "Monthly Budget Spreadsheet",
    description:
      "The exact three-number budget template from my articles — pre-built formulas, weekly review tab, zero setup required.",
    type: "Template",
    url: "https://payhip.com/awdahir",
  },
  {
    title: "Debt Payoff Tracker",
    description:
      "Visual snowball/avalanche tracker. Enter your balances once and watch the payoff order, dates, and interest saved update automatically.",
    type: "Template",
    url: "https://payhip.com/awdahir",
  },
  {
    title: "The Awdahir Reading List",
    description:
      "Twelve books that shaped how I think about money — from behavioral psychology to investing classics — with notes on who each one is for.",
    type: "Reading list",
    url: "https://awdahir.substack.com",
  },
  {
    title: "Compound Interest Calculator",
    description:
      "See what your monthly savings become in 10, 20, 30 years. The single most motivating page on the internet for new investors.",
    type: "Tool",
    url: "https://awdahir.substack.com",
  },
  {
    title: "Net Worth Tracker",
    description:
      "One sheet, updated quarterly. Assets minus debts, graphed over time — the only financial scoreboard that actually matters.",
    type: "Template",
    url: "https://payhip.com/awdahir",
  },
];

export const TOPICS = [
  "Budgeting",
  "Saving",
  "Debt freedom",
  "Investing basics",
  "Money mindset",
  "Freelance finance",
  "Emergency funds",
  "Wealth building",
];
