export type Page =
  | "home"
  | "about"
  | "blog"
  | "post"
  | "resources"
  | "store"
  | "insights"
  | "insight-post"
  | "contact";
